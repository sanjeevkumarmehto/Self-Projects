import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';
import { User } from '../user.model';
@Component({
  selector: 'app-user-list',
  templateUrl: './user-list.component.html',
  styleUrls: ['./user-list.component.css']
})
export class UserListComponent implements OnInit {

  users: User[] = [];//all users
  filteredUsers:User[]=[]; //filtered users
  constructor(private userService: UserService) {

  }

  ngOnInit(): void {
    this.getUsers();
  }

  getUsers(): void {
    this.userService.GetUsers().subscribe(usersData => {
      this.users = usersData;
      this.filteredUsers=usersData;
    })
  }

  deleteUser(id: number): void {
    if (confirm("Are you sure you want to delete user?")) {
      this.userService.DeleteUser(id).subscribe(() => {
        this.getUsers();
      })
    }
  }
  //whatever data the child component is going to emit, will be received
  //in this function's parameter
  onUsersFiltered(filteredData: User[]) {
    this.filteredUsers=filteredData;
  }
}
