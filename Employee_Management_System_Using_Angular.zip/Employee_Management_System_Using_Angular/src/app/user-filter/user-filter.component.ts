import { Component, EventEmitter, Input, Output } from '@angular/core';
import { User } from '../user.model';

@Component({
  selector: 'app-user-filter',
  templateUrl: './user-filter.component.html',
  styleUrls: ['./user-filter.component.css']
})
export class UserFilterComponent {
  //

  selectedRole: string = 'all';

  @Input()
  users: User[] = [];

  @Output()
  usersFiltered: EventEmitter<User[]> = new EventEmitter<User[]>();

  onFilterChange(roleType: string) {
    const filtered = (roleType == 'all') ? this.users : this.users.filter(user => user.type === roleType);
    this.usersFiltered.emit(filtered);
    console.log(filtered);
    
  }


}

