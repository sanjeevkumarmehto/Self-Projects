import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Observable } from "rxjs";
import { User } from "./user.model";

@Injectable()
export class UserService {
    private apiUrl: string = "http://localhost:3000/users";

    constructor(private http: HttpClient) {

    }

    GetUsers(): Observable<User[]> {
        return this.http.get<User[]>(this.apiUrl);
    }
    GetUserById(id: number): Observable<User> {
        return this.http.get<User>(`${this.apiUrl}/${id}`);
    }
    CreateUser(user: User): Observable<User> {
        return this.http.post<User>(this.apiUrl, user);
    }
    updateUser(user: User): Observable<User> {
        return this.http.put<User>(`${this.apiUrl}/${user.id}`, user);
    }
    DeleteUser(id: number): Observable<any> {
        return this.http.delete(`${this.apiUrl}/${id}`);
    }

}