import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import {HttpClientModule} from '@angular/common/http';
import { HttpBasicDemoComponent } from './http-basic-demo/http-basic-demo.component';
import { GitHubService } from './github.service';
import { HomeComponent } from './home/home.component';
import { CreateUserComponent } from './create-user/create-user.component';
import { EditUserComponent } from './edit-user/edit-user.component';
import { UserListComponent } from './user-list/user-list.component';
import { NavbarComponent } from './navbar/navbar.component';
import { UserFilterComponent } from './user-filter/user-filter.component';
import { UserService } from './user.service';


@NgModule({
  declarations: [
    AppComponent,
    HttpBasicDemoComponent,
    HomeComponent,
    CreateUserComponent,
    EditUserComponent,
    UserListComponent,
    NavbarComponent,
    UserFilterComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule
  ],
  providers: [GitHubService,UserService],
  bootstrap: [AppComponent]
})
export class AppModule { }
