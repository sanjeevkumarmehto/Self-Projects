import { Injectable } from "@angular/core";
import { HttpClient } from '@angular/common/http';
import { Github } from "./github.model";
import { Observable } from 'rxjs';

@Injectable()
export class GitHubService {

    baseUrl: string = "https://api.github.com/";

    constructor(private http: HttpClient) {

    }


    GetRepositories(username:string ):Observable<Github[]>{
        return this.http.get<Github[]>(this.baseUrl + "users/" + username + "/repos");
    }

}