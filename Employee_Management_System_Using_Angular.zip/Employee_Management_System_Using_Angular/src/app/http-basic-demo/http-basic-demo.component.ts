import { Component } from '@angular/core';
import { Github } from '../github.model';
import { GitHubService } from '../github.service';

@Component({
  selector: 'app-http-basic-demo',
  templateUrl: './http-basic-demo.component.html',
  styleUrls: ['./http-basic-demo.component.css']
})
export class HttpBasicDemoComponent {
  repos?: Github[];
  username: string = 'microsoft';

  constructor(private githubService: GitHubService) {

  }


  GetRepos(){
    this.githubService.GetRepositories(this.username).subscribe(repoData=>{
      this.repos=repoData;
    })
  }
}
