import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { UserService } from '../user.service';

@Component({
  selector: 'app-edit-user',
  templateUrl: './edit-user.component.html',
  styleUrls: ['./edit-user.component.css']
})
export class EditUserComponent implements OnInit {
  userForm: FormGroup

  constructor(private userService: UserService, private fb: FormBuilder,
    private router: Router, private route: ActivatedRoute) {
  
    this.userForm = this.fb.group({
      id:[],
      name: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      type: ['', Validators.required]
    })
  }

  ngOnInit(): void {
    this.userService.GetUserById(this.route.snapshot.params["id"]).subscribe(user=>{
      this.userForm.patchValue(user);
    })
  }

  updateUser():void{
    if (this.userForm.valid) {
      this.userService.updateUser(this.userForm.value).subscribe(user => {
        console.log("user edited", user);
        // this.userForm.reset();
        this.router.navigate(['/users']);
      })
    }
  }



}
