export interface Github{
    id:number;
    name:string ;
    html_url:string;
    description:string;
    full_name:string
}