package com.newtalentapp.training.service;

import com.newtalentapp.training.entities.Certification;
import com.newtalentapp.training.entities.EmployeeCertificationMapping;

import java.util.List;
import java.util.Map;

public interface CertificationService {
    List<Certification> getAllCertifications();
    Certification getCertificateById(Integer id);
    Certification createCertification(Certification certification);
    Certification updateCertification(Certification Certification);
    void deleteCertification(Integer id);
    List<Certification> findCertificationStatus(String value);

    EmployeeCertificationMapping enrollCertification(Integer employeeId, Integer certificationID);
    Map<String, Integer> countCertificationOnStatus();
}
