package com.newtalentapp.training.service;

import com.newtalentapp.training.Exception.RecordNotFoundException;
import com.newtalentapp.training.entities.Certification;
import com.newtalentapp.training.entities.EmployeeCertificationMapping;
import com.newtalentapp.training.entities.Training;
import com.newtalentapp.training.repos.CertificationRepository;
import com.newtalentapp.training.repos.EmployeeCertificationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

@Service
public class CertificationServiceImpl implements CertificationService{
    @Autowired
    private CertificationRepository certificationRepository;

    @Autowired
    private EmployeeCertificationRepository employeeCertificationRepository;
    @Override
    public List<Certification> getAllCertifications() {
        return certificationRepository.findAllByOrderByUpdatedAtDesc();
    }

    @Override
    public Certification getCertificateById(Integer id) {
        return certificationRepository.findById(id).orElseThrow();
    }

    @Override
    public Certification createCertification(Certification certification) {
        Date updatedDate = new Date();
        certification.setUpdatedAt(updatedDate);
        return certificationRepository.save(certification);
    }

    @Override
    public Certification updateCertification(Certification certification) {
        Date updatedDate = new Date();
        certification.setUpdatedAt(updatedDate);
        return certificationRepository.save(certification);
    }

    @Override
    public void deleteCertification(Integer id) {
        certificationRepository.deleteById(id);
    }

    @Override
    public List<Certification> findCertificationStatus(String value) {
        return certificationRepository.findByCertificationStatusContains(value);
    }

    @Override
    public EmployeeCertificationMapping enrollCertification(Integer employeeId, Integer certificationID){
        EmployeeCertificationMapping employeeCertificationMapping = new EmployeeCertificationMapping();
        try{
            employeeCertificationMapping.setEmpId(employeeId);
            Certification certification = certificationRepository.findById(certificationID).
                    orElseThrow(() ->  new RecordNotFoundException("No certification found"));
            employeeCertificationMapping.setCertificationStatus(certification.getCertificationStatus());
            employeeCertificationMapping.setCertificationId(certificationID);
        } catch (Exception e){
            employeeCertificationMapping = null;
            System.out.println("Error while Enrolling Certification | EmployeeID: "+ employeeId + " | CertificationID: " + certificationID);
        }

        return employeeCertificationRepository.save(employeeCertificationMapping);

    }

	@Override
	public Map<String, Integer> countCertificationOnStatus() {
		List<Certification> findAll = certificationRepository.findAll();

		HashMap<String, Integer> hs = new HashMap<>();
		if (findAll.size() != 0) {

			Iterator<Certification> iterator = findAll.iterator();
			while (iterator.hasNext()) {
				Certification certification = iterator.next();
				
				if (hs.containsKey(certification.getCertificationStatus())) {

					hs.put(certification.getCertificationStatus(), hs.get(certification.getCertificationStatus()) + 1);

				} else {
					hs.put(certification.getCertificationStatus(), 1);
				}

			}
		}

		return hs;
	}

}
