package com.newtalentapp.training.DTO;

public class EmployeeCertificationDTO {


    private Integer employeeID;

    private Integer certificationID;

    public Integer getEmployeeID() {
        return employeeID;
    }

    public void setEmployeeID(Integer employeeID) {
        this.employeeID = employeeID;
    }

    public Integer getCertificationID() {
        return certificationID;
    }

    public void setCertificationID(Integer certificationID) {
        this.certificationID = certificationID;
    }
}
