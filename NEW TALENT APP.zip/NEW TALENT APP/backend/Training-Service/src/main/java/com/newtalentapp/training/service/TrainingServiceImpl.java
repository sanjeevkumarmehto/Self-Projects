package com.newtalentapp.training.service;

import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;


import com.newtalentapp.training.Exception.RecordNotFoundException;
import com.newtalentapp.training.entities.EmployeeTrainingMapping;
import com.newtalentapp.training.repos.EmployeeTrainingRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.newtalentapp.training.entities.Training;
import com.newtalentapp.training.repos.TrainingRepository;

// TrainingServiceImpl.java (implementation)
@Service
public class TrainingServiceImpl implements TrainingService {
    @Autowired
    private TrainingRepository trainingRepository;

    @Autowired
    private EmployeeTrainingRepository employeeTrainingRepository;
    @Override
    public List<Training> getAllTrainings() {
        return trainingRepository.findAllByOrderByUpdatedAtDesc();
    }
    @Override
    public Training getTrainingById(Integer id) {
        return trainingRepository.findById(id).orElseThrow();
    }
    @Override
    public Training createTraining(Training training) {
        Date updatedDate = new Date();
        training.setUpdatedAt(updatedDate);
        return trainingRepository.save(training);
    }
    @Override
    public Training updateTraining(Training training) {
        Date updatedDate = new Date();
        training.setUpdatedAt(updatedDate);
        return trainingRepository.save(training);
    }
    @Override
    public void deleteTraining(Integer id) {
        trainingRepository.deleteById(id);
    }

    @Override
    public List<Training> findTrainingByStatus(String value) {
        return trainingRepository.findByTrainingStatusContains(value);
    }

    @Override
    public EmployeeTrainingMapping enrollTraining(Integer employeeID, Integer trainingID){
        EmployeeTrainingMapping employeeTrainingMapping = new EmployeeTrainingMapping();
        employeeTrainingMapping.setEmpId(employeeID);
        employeeTrainingMapping.setTrainingId(trainingID);
        Training training = trainingRepository.findById(trainingID).
                orElseThrow(() ->  new RecordNotFoundException("No training found"));
        employeeTrainingMapping.setTrainingStatus(training.getTrainingStatus());
        return employeeTrainingRepository.save(employeeTrainingMapping);
    }
    
    public Map<String, Integer> countTrainingOnStatus() {

		List<Training> findAll = trainingRepository.findAll();
		
		
		HashMap<String, Integer> hs=new HashMap<>();
		if(findAll.size()!=0) {
			
			Iterator<Training> iterator = findAll.iterator();
			while(iterator.hasNext())
			{
				Training training = iterator.next();
				training.getTrainingStatus();
				if(hs.containsKey(training.getTrainingStatus())) {
					
					hs.put(training.getTrainingStatus(), hs.get(training.getTrainingStatus())+1);
					
				}
				else {
					hs.put(training.getTrainingStatus(), 1);
				}
				
			}
		}
		
		return hs;
	}
}