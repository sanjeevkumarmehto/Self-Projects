package com.newtalentapp.training.repos;

import com.newtalentapp.training.entities.Certification;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface CertificationRepository extends JpaRepository<Certification, Integer> {
    public List<Certification> findAllByOrderByUpdatedAtDesc();
    public List<Certification> findByCertificationStatusContains(String keyword);
}
