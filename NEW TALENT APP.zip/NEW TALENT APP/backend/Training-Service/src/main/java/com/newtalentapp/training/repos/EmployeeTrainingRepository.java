package com.newtalentapp.training.repos;

import com.newtalentapp.training.entities.EmployeeTrainingMapping;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EmployeeTrainingRepository extends JpaRepository<EmployeeTrainingMapping, Integer> {
}
