package com.newtalentapp.training.repos;


import org.springframework.data.jpa.repository.JpaRepository;

import com.newtalentapp.training.entities.Training;

import java.util.List;

// TrainingRepository.java (repository interface)
public interface TrainingRepository extends JpaRepository<Training, Integer> {
    public List<Training> findAllByOrderByUpdatedAtDesc();
    public List<Training> findByTrainingStatusContains(String value);
}
