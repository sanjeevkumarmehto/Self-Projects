package com.newtalentapp.training.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

import java.util.Date;


@Entity(name="Certification_Details")
public class Certification {
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer certificationId;
	
	private String  certificationName;
	
	private String certificationStatus;

	private String certificationSkill;

	private Date updatedAt;

	public Integer getCertificationId() {
		return certificationId;
	}

	public void setCertificationId(Integer certificationId) {
		this.certificationId = certificationId;
	}

	public String getCertificationName() {
		return certificationName;
	}

	public void setCertificationName(String certificationName) {
		this.certificationName = certificationName;
	}

	public String getCertificationStatus() {
		return certificationStatus;
	}

	public void setCertificationStatus(String certificationStatus) {
		this.certificationStatus = certificationStatus;
	}


	public String getCertificationSkill() {
		return certificationSkill;
	}

	public void setCertificationSkill(String certificationSkill) {
		this.certificationSkill = certificationSkill;
	}

	public Date getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(Date updatedAt) {
		this.updatedAt = updatedAt;
	}

	@Override
	public String toString() {
		return "Certification [certificationId=" + certificationId + ", certificationName=" + certificationName
				+ ", certificationStatus=" + certificationStatus + "]";
	}
	
	
	
}
