package com.newtalentapp.training.repos;

import com.newtalentapp.training.entities.EmployeeCertificationMapping;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EmployeeCertificationRepository extends JpaRepository<EmployeeCertificationMapping, Integer> {
}
