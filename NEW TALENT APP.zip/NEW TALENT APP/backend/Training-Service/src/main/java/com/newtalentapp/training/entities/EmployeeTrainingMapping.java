package com.newtalentapp.training.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity(name="EMPLOYEE_TRAINING_MAPPING")
public class EmployeeTrainingMapping {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer empTrainingMappingId;
    private Integer  empId;

    private Integer trainingId;

    private String trainingStatus;

    public Integer getEmpTrainingMappingId() {
        return empTrainingMappingId;
    }

    public void setEmpTrainingMappingId(Integer empTrainingMappingId) {
        this.empTrainingMappingId = empTrainingMappingId;
    }
    public Integer getEmpId() {
        return empId;
    }

    public void setEmpId(Integer empId) {
        this.empId = empId;
    }

    public Integer getTrainingId() {
        return trainingId;
    }

    public void setTrainingId(Integer trainingId) {
        this.trainingId = trainingId;
    }

    public String getTrainingStatus() {
        return trainingStatus;
    }

    public void setTrainingStatus(String trainingStatus) {
        this.trainingStatus = trainingStatus;
    }

}
