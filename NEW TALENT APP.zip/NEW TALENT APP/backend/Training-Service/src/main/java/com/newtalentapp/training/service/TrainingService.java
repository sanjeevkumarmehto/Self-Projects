package com.newtalentapp.training.service;



// TrainingService.java (interface)

import java.util.List;
import java.util.Map;

import com.newtalentapp.training.entities.EmployeeTrainingMapping;
import com.newtalentapp.training.entities.Training;

public interface TrainingService {
    List<Training> getAllTrainings();
    Training getTrainingById(Integer id);
    Training createTraining(Training training);
    Training updateTraining(Training training);

    void deleteTraining(Integer id);

    List<Training> findTrainingByStatus(String value);

    EmployeeTrainingMapping enrollTraining(Integer employeeID, Integer trainingID);
     Map<String, Integer> countTrainingOnStatus();
}