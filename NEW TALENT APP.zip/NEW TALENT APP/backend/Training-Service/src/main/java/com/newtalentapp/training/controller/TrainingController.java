package com.newtalentapp.training.controller;

import java.util.List;
import java.util.Map;

import com.newtalentapp.training.DTO.EmployeeTrainingDTO;
import com.newtalentapp.training.entities.EmployeeTrainingMapping;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.newtalentapp.training.entities.Training;
import com.newtalentapp.training.service.TrainingService;

//TrainingController.java
@RestController
@RequestMapping("/api/trainings")
@CrossOrigin(origins = "*")
public class TrainingController {

	@Autowired
	private TrainingService trainingService;

	// CREATE
	@PostMapping("/createTraining")
	public ResponseEntity<Training> createTraining(@RequestBody Training training) {
		Training newTraining = trainingService.createTraining(training);
		return new ResponseEntity<>(newTraining, HttpStatus.CREATED);
	}

	// READ ALL
	@GetMapping("/getAllTrainings")
	public ResponseEntity<List<Training>> getAllTrainings() {
		List<Training> trainings = trainingService.getAllTrainings();
		return new ResponseEntity<>(trainings, HttpStatus.OK);
	}

	// READ BY ID
	@GetMapping("/getTraining/{id}")
	public ResponseEntity<Training> getTrainingById(@PathVariable Integer id) {
		Training training = trainingService.getTrainingById(id);
		return new ResponseEntity<>(training, HttpStatus.OK);
	}

	// UPDATE
	@PutMapping("/updateTraining/{id}")
	public ResponseEntity<Training> updateTraining(@PathVariable Integer id, @RequestBody Training training) {
		training.setTrainingId(id);
		Training updatedTraining = trainingService.updateTraining(training);
		return new ResponseEntity<>(updatedTraining, HttpStatus.OK);
	}

	// DELETE
	@DeleteMapping("/deleteTraining/{id}")
	public ResponseEntity<Void> deleteTraining(@PathVariable Integer id) {
		trainingService.deleteTraining(id);
		return new ResponseEntity<>(HttpStatus.NO_CONTENT);
	}

	@GetMapping("/getTraining/status")
	public ResponseEntity<List<Training>> getCertificationWithFilter(@RequestParam(defaultValue = "InProgress") String value) {
		List<Training> trainings = trainingService.findTrainingByStatus(value);
		return new ResponseEntity<>(trainings, HttpStatus.OK);
	}

	@PostMapping("/enroll")
	public ResponseEntity<EmployeeTrainingMapping> enrollTraining(@RequestBody EmployeeTrainingDTO employeeTrainingDTO){
		EmployeeTrainingMapping employeeTrainingMapping = trainingService.enrollTraining(employeeTrainingDTO.getEmployeeID(), employeeTrainingDTO.getTrainingID());
		return new ResponseEntity<>(employeeTrainingMapping, HttpStatus.OK);
	}
	
	
	@GetMapping("/countTrainingOnStatus")
	public ResponseEntity<Map<String, Integer>> countTrainingOnStatus(){
		
		Map<String, Integer> countTrainingOnStatus = trainingService.countTrainingOnStatus();
		return new ResponseEntity<>(countTrainingOnStatus, HttpStatus.OK);
	}
}