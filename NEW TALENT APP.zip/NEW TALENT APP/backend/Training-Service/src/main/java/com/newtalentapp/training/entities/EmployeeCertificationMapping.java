package com.newtalentapp.training.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
@Entity(name="EMPLOYEE_CERTIFICATION_MAPPING")
public class EmployeeCertificationMapping {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer empCertificationMappingId;
    private Integer  empId;

    private Integer certificationId;

    private String certificationStatus;

    public Integer getEmpCertificationMappingId() {
        return empCertificationMappingId;
    }

    public void setEmpCertificationMappingId(Integer empCertificationMappingId) {
        this.empCertificationMappingId = empCertificationMappingId;
    }
    public Integer getEmpId() {
        return empId;
    }

    public void setEmpId(Integer empId) {
        this.empId = empId;
    }

    public Integer getCertificationId() {
        return certificationId;
    }

    public void setCertificationId(Integer certificationId) {
        this.certificationId = certificationId;
    }

    public String getCertificationStatus() {
        return certificationStatus;
    }

    public void setCertificationStatus(String certificationStatus) {
        this.certificationStatus = certificationStatus;
    }

}
