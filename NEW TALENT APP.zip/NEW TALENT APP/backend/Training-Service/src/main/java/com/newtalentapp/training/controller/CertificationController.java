package com.newtalentapp.training.controller;

import com.newtalentapp.training.DTO.EmployeeCertificationDTO;
import com.newtalentapp.training.entities.Certification;
import com.newtalentapp.training.entities.EmployeeCertificationMapping;
import com.newtalentapp.training.service.CertificationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;
import java.util.Objects;

@RestController
@RequestMapping("/api/certification")
@CrossOrigin(origins = "*")
public class CertificationController {
    @Autowired
    private CertificationService certificationService;

    @GetMapping("/getAllCertifications")
    public ResponseEntity<List<Certification>> getAllCertification() {
        List<Certification> certifications = certificationService.getAllCertifications();
        return new ResponseEntity<>(certifications, HttpStatus.OK);
    }

    @GetMapping("/getCertification/{id}")
    public ResponseEntity<Certification> getCertificationById(@PathVariable Integer id) {
        Certification certification = certificationService.getCertificateById(id);
        return new ResponseEntity<>(certification, HttpStatus.OK);
    }

    @PostMapping("/createCertification")
    public ResponseEntity<Certification> createCertification(@RequestBody Certification certification) {
        Certification newCertification = certificationService.createCertification(certification);
        return new ResponseEntity<>(newCertification, HttpStatus.CREATED);
    }

    @PutMapping("/updateCertification/{id}")
    public ResponseEntity<Certification> updateCertification(@PathVariable Integer id, @RequestBody Certification certification) {
        certification.setCertificationId(id);
        Certification updatedCertification = certificationService.updateCertification(certification);
        return new ResponseEntity<>(updatedCertification, HttpStatus.OK);
    }

    // DELETE
    @DeleteMapping("/deleteCertification/{id}")
    public ResponseEntity<Void> deleteCertification(@PathVariable Integer id) {
        certificationService.deleteCertification(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

    @GetMapping("/getCertification/status")
    public ResponseEntity<List<Certification>> getCertificationWithFilter(@RequestParam(defaultValue = "Not Started") String value) {
        List<Certification> certifications = certificationService.findCertificationStatus(value);
        return new ResponseEntity<>(certifications, HttpStatus.OK);
    }

    @PostMapping("/enroll")
    public ResponseEntity<Object> enrollCertification(@RequestBody EmployeeCertificationDTO employeeCertificationDTO){
        EmployeeCertificationMapping employeeCertificationMapping = certificationService.enrollCertification(employeeCertificationDTO.getEmployeeID(), employeeCertificationDTO.getCertificationID());
        if(Objects.isNull(employeeCertificationMapping)){
            return new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);
        }
        return new ResponseEntity<>(employeeCertificationMapping, HttpStatus.OK);

    }
    
    
   
    
    
    
    @GetMapping("/countCertificationOnStatus")
	public ResponseEntity<Map<String, Integer>> countTrainingOnStatus(){
		
		Map<String, Integer> countTrainingOnStatus = certificationService.countCertificationOnStatus();
		return new ResponseEntity<>(countTrainingOnStatus, HttpStatus.OK);
	}
    

}
