package com.newtalentapp.employee.controller;


import java.util.List;
import java.util.Objects;

import com.newtalentapp.employee.dto.LoginRequestDto;
import com.newtalentapp.employee.dto.LoginResponseDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.newtalentapp.employee.entities.Employee;
import com.newtalentapp.employee.service.EmployeeService;

@RestController
@RequestMapping("/api/employee")
@CrossOrigin(origins = "*")
public class EmployeeController {

	@Autowired
	private EmployeeService employeeService;
	
	
	
	@PutMapping("/forgotPassword")
	public Employee forgotPassword(@RequestBody Employee employee) {
//		return employeeService.createUser(employee);
//		
		System.out.println("employee id is: "+employee.getEmpId());
		return employeeService.updatePassword( employee);
//		return employeeService.getUserById(employee.getEmpId());
	}

	
	@PostMapping("/login")
	public ResponseEntity<Object> validateUser(@RequestBody LoginRequestDto loginRequestDto) {

		LoginResponseDto loginDetails = employeeService.validateUser(loginRequestDto);
		if(loginDetails.getLoggedIn()){
			return new ResponseEntity<>(loginDetails, HttpStatus.OK);
		} else{
			return new ResponseEntity<>(loginDetails, HttpStatus.BAD_REQUEST);
		}

	}

	@GetMapping("/getall")
	public List<Employee> getAllEmployees() {
		return employeeService.getAllEmployees();
	}

	// GET /api/employees/{id}
	@GetMapping("getEmployeeById/{id}")
	public Employee getEmployeeById(@PathVariable Integer id) {
		return employeeService.getUserById(id);
	}

	// POST /api/employees
	@PostMapping("/createemp")
	public Employee createEmployee(@RequestBody Employee employee) {
		return employeeService.createUser(employee);
	}

	// PUT /api/employees/{id}
	@PutMapping("UpdateEmp/{id}")
	public Employee updateEmployee(@PathVariable Integer id, @RequestBody Employee employee) {
		return employeeService.updateUser(id, employee);
	}

	// DELETE /api/employees/{id}
	@DeleteMapping("DeleteEmpbyID/{id}")
	public void deleteEmployee(@PathVariable Integer id) {
		employeeService.deleteUser(id);
	}

}
