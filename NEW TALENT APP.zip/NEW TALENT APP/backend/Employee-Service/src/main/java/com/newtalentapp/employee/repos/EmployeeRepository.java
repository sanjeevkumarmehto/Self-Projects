package com.newtalentapp.employee.repos;

import org.springframework.data.jpa.repository.JpaRepository;

import com.newtalentapp.employee.entities.Employee;

import java.util.List;

public interface EmployeeRepository extends JpaRepository<Employee, Integer> {
    public Employee findByEmail(String email);
}



	