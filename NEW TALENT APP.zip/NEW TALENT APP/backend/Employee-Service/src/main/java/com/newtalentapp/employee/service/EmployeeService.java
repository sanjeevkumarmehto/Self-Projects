package com.newtalentapp.employee.service;

import java.util.List;
import java.util.Objects;

import com.newtalentapp.employee.dto.LoginRequestDto;
import com.newtalentapp.employee.dto.LoginResponseDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.newtalentapp.employee.entities.Employee;
import com.newtalentapp.employee.repos.EmployeeRepository;

@Service
public class EmployeeService {
	
	
	@Autowired
	private EmployeeRepository employeeRepository;
	
	public List<Employee> getAllEmployees() {
        return employeeRepository.findAll();
	}
	public Employee getUserById(Integer id) {
        return employeeRepository.findById(id).orElseThrow();
	}
	
	public Employee getUserByEmail(String emailId) {
        return employeeRepository.findByEmail(emailId);
	}
	
	 public Employee createUser(Employee user) {
			user.setPassword("default");

	        return employeeRepository.save(user);

	 }
	 public Employee updateUser(Integer id, Employee user) {
	        Employee existingUser = getUserById(id);
	        existingUser.setEmail(user.getEmail());
	        existingUser.setPassword(user.getPassword());
	       
	        return employeeRepository.save(user);
	    }
	 
	 public Employee updatePassword(Employee user) {
	        Employee existingUser = getUserByEmail(user.getEmail());
	        existingUser.setEmail(user.getEmail());
	        existingUser.setPassword(user.getPassword());
	       System.out.println("existing user->"+existingUser);
	        return employeeRepository.save(existingUser);
	    }
	 
	 public void deleteUser(Integer id) {
	        employeeRepository.deleteById(id);
	    }

	public LoginResponseDto validateUser(LoginRequestDto loginDetails){
		LoginResponseDto loginResponse = new LoginResponseDto();
		Employee employee = employeeRepository.findByEmail(loginDetails.getEmail());
		if(Objects.isNull(employee)){
			System.out.println("No such user");
			loginResponse.setLoggedIn(false);
			return loginResponse;
		}
		else if(employee.getPassword().equals(loginDetails.getPassword())){
			loginResponse.setLoggedIn(true);
			loginResponse.setAdmin(employee.isAdmin());
			loginResponse.setUserId(employee.getEmpId());
			loginResponse.setEmail(employee.getEmail());
			employee.setRetry(0);
			employeeRepository.save(employee);
		} else if(Objects.nonNull(employee)) {
			employee.setRetry(employee.getRetry()+1);
			employeeRepository.save(employee);
		}
		return loginResponse;
	}
}
