package com.newtalentapp.employee.dto;

public class EmployeeRequestDto {
	private String employeeEmailId;
	private String password;
	public String getEmployeeEmailId() {
		return employeeEmailId;
	}
	public void setEmployeeEmailId(String employeeEmailId) {
		this.employeeEmailId = employeeEmailId;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	@Override
	public String toString() {
		return "EmployeeRequestDto [employeeEmailId=" + employeeEmailId + ", password=" + password + "]";
	}
	
}
