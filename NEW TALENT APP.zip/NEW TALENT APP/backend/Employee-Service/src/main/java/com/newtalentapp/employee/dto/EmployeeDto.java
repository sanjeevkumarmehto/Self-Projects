package com.newtalentapp.employee.dto;




public class EmployeeDto {

}
