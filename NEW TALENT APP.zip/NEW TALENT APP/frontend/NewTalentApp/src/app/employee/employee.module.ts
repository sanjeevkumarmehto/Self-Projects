import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CreateEmployeeComponent } from './create-employee/create-employee.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { ViewEmployeeComponent } from './view-employee/view-employee.component';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { UpdateEmployeeComponent } from './update-employee/update-employee.component';
import { RouterModule, Routes } from '@angular/router';
import { NgxPaginationModule } from 'ngx-pagination';
import { SharedModule } from '../service/shared/shared.module';
import { NgxSpinnerModule } from "ngx-spinner";

const routes: Routes = [
  { path: '', component: ViewEmployeeComponent },
  { path: 'createemployee', component: CreateEmployeeComponent },
  { path: 'update/:id', component: UpdateEmployeeComponent },
];

@NgModule({
  declarations: [
    CreateEmployeeComponent,
    ViewEmployeeComponent,
    UpdateEmployeeComponent,
    // SearchPipe
  ],
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA
  ],
  imports: [
    CommonModule,
    HttpClientModule,
    ReactiveFormsModule,
    FormsModule,
    SharedModule,
    NgxPaginationModule,
    MatButtonModule,
    MatIconModule,
    NgxSpinnerModule,
    RouterModule.forChild(routes),
  ]
})
export class EmployeeModule { }
