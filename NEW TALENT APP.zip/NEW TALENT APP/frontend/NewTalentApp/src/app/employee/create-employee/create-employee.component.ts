import { Component, OnInit } from '@angular/core';
import { EmployeeService } from 'src/app/service/employee.service';
import { FormBuilder, FormGroup, NgForm, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Title } from '@angular/platform-browser';
import { ToastrService } from 'ngx-toastr';



@Component({
  selector: 'app-create-employee',
  templateUrl: './create-employee.component.html',
  styleUrls: ['./create-employee.component.css']
})
export class CreateEmployeeComponent {

  employeeForm: FormGroup;


  constructor(private employeeService: EmployeeService,private toasterService: ToastrService, 
    private fb: FormBuilder, private router: Router,private title:Title) {
    this.employeeForm = this.fb.group({
      id:[],
      // empId: ['',[Validators.required]],
      practiseName: ['', Validators.required],
      // sub_practice_name: ['',Validators.required],
      fullName:['',Validators.required],
      email: ['', [Validators.required, Validators.email,Validators.pattern('^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$')]],
      location: ['',Validators.required],
      grade: ['',Validators.required],
      primarySkills: ['',Validators.required],


    })
  }

 

  validateControl = (controlName: string) => {
    if (this.employeeForm.get(controlName)?.invalid && this.employeeForm.get(controlName)?.touched) {
      return true;
    }
    return false;
  }



createEmployee() {
  this.employeeService.createEmployee(this.employeeForm.value).subscribe(result=>{
    // alert('Employee  Created Successfully..');
    console.log(result);
    this.toasterService.success("Employee Successfully Created", "Success");
    //reset();
    this.router.navigate(['dashboard/employee']);
  }, err=>{
    //alert('Property is Added Successfully');
    this.toasterService.error("Server Error while login", "Error");
    // console.log(err);
  })
}
redirectList() {
 
    alert('Are you sure cancel the change ?');
    //reset();
    this.router.navigate(['dashboard/employee']);
 
}
}
