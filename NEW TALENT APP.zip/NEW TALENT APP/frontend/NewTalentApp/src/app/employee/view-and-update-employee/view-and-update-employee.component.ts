import { Component } from '@angular/core';

@Component({
  selector: 'app-view-and-update-employee',
  templateUrl: './view-and-update-employee.component.html',
  styleUrls: ['./view-and-update-employee.component.css']
})
export class ViewAndUpdateEmployeeComponent {

}
