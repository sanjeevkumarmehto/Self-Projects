import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewAndUpdateEmployeeComponent } from './view-and-update-employee.component';

describe('ViewAndUpdateEmployeeComponent', () => {
  let component: ViewAndUpdateEmployeeComponent;
  let fixture: ComponentFixture<ViewAndUpdateEmployeeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ViewAndUpdateEmployeeComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ViewAndUpdateEmployeeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
