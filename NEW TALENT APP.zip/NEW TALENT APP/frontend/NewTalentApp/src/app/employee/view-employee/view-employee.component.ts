import { HttpClient } from '@angular/common/http';
import { Component, OnInit, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { Router } from '@angular/router';
import { EmployeeService } from 'src/app/service/employee.service';
import { Employee } from 'src/app/models/employee.model';
import { combineLatest, map, Observable } from 'rxjs';
import { Training } from 'src/app/models/training';
import { ToastrService } from 'ngx-toastr';
import { NgxSpinner, NgxSpinnerService } from 'ngx-spinner';



@Component({
  selector: 'app-view-employee',
  templateUrl: './view-employee.component.html',
  styleUrls: ['./view-employee.component.css']
})
export class ViewEmployeeComponent implements OnInit  {

  employeeList!: Employee[];
  searchText: any;
  page: number = 1;
  totalLength: any;
  newEmployee?: Observable<Employee[]>;
  showPortfolio:boolean=false;

  // filteredEmployees!: Observable<Employee[]>;

  constructor(private employeeService: EmployeeService,private toasterService:ToastrService, private router: Router,
    private httpclient: HttpClient, private spinnerService:NgxSpinnerService) {

  }

  ngOnInit(): void {
    this.spinnerService.show();
    this.employeeList=[];
    this.employeeService.getEmployeeList().subscribe(employee => {
      setTimeout(() => {
        /** spinner ends after 5 seconds */
        this.showPortfolio=true;
        this.spinnerService.hide();
      }, 1000);
      this.employeeList = employee;
    }, err => {
      console.log(err);
    });
    // this.spinnerService.hide();
  }

  addEmployee() {
    // this.toasterService.success("Employee Successfully Added ", "Success");
    this.router.navigate(['dashboard/employee/createemployee']);
  }

  deleteEmployee(id: any) {
    if (confirm("Are you sure to delete record?"))
      this.employeeService.deleteEmployee(id).subscribe(res => {
        // alert("Record Delete Successfully..")
        this.toasterService.success("Employee Successfully Deleted ", "Delete");
        this.ngOnInit();
      });
  }

  updateEmployee(e: Employee) {
    this.router.navigate(['dashboard/employee/update', e.empId]);
    // this.toasterService.success("Employee Successfully Updated ", "Success");
  }




}


