import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, NgForm, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { EmployeeService } from 'src/app/service/employee.service';
// import { Employee } from 'src/app/model/employee.model';

@Component({
  selector: 'app-update-employee',
  templateUrl: './update-employee.component.html',
  styleUrls: ['./update-employee.component.css']
})
export class UpdateEmployeeComponent implements OnInit {

  employeeId!: any;
  editEmployeeForm: FormGroup;
  bufferEmployeeForm?: FormGroup;
  // toasterService: any;
  constructor(private route: ActivatedRoute,private toasterService:ToastrService, private employeeService: EmployeeService,
    private router: Router, private fb: FormBuilder) {
    this.editEmployeeForm = this.fb.group({
      id: [],
      empId: ['', [Validators.required]],
      practiseName: ['', Validators.required],
      // sub_practice_name: ['', Validators.required],
      fullName: ['', Validators.required],
      email:['', [Validators.required, Validators.email]],
      location: ['', Validators.required],
      grade: ['', Validators.required],
      primarySkills: ['', Validators.required],


    });
    this.editEmployeeForm.controls['practiseName'].disable();
    this.editEmployeeForm.controls['fullName'].disable();
    this.editEmployeeForm.controls['email'].disable();

  }

  ngOnInit(): void {

    this.employeeService.getEmployeeById(this.route.snapshot.params["id"]).subscribe((employee: any) => {
      console.log(employee);
      this.editEmployeeForm.patchValue(employee);
    })

  }

  updateEmployee() {
    let employeeVal = {
      empId:this.editEmployeeForm.controls['empId'].value,
      practiseName:this.editEmployeeForm.controls['practiseName'].value,
      // sub_practice_name: ['', Validators.required],
      fullName:this.editEmployeeForm.controls['fullName'].value,
      email:this.editEmployeeForm.controls['email'].value,
      location:this.editEmployeeForm.controls['location'].value,
      grade:this.editEmployeeForm.controls['grade'].value,
      primarySkills:this.editEmployeeForm.controls['primarySkills'].value
    }
    this.employeeService.updateEmployee(employeeVal).subscribe(result=>{
      // alert('Employee  Updated Successfully');
      this.toasterService.success("Employee Updated Successfully ", "Success");
      console.log(result);
      //reset();
      this.router.navigate(['dashboard/employee']);
    }, err=>{
      //alert('Property is Added Successfully');
      // alert('You did something wrong.');
      this.toasterService.error("Employee Updation failed ", "Error");
      console.log(err);
    })
  }





}
