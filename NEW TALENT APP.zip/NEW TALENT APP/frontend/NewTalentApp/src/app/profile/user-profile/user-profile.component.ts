import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { ChartOptions } from 'chart.js';
import { Certification } from 'src/app/models/certification';
import { Employee } from 'src/app/models/employee.model';
import { StatusCount } from 'src/app/models/statusCount';


import { Training } from 'src/app/models/training';
import { EmployeeService } from 'src/app/service/employee.service';
import { TrainingService } from 'src/app/service/training.service';

@Component({
  selector: 'app-user-profile',
  templateUrl: './user-profile.component.html',
  styleUrls: ['./user-profile.component.css']
})
export class UserProfileComponent {
  tab: number = 0;

  num : number =0;

  employee?: Employee;


  trainingStatusCount : StatusCount=new StatusCount();
  certificationStatusCount : StatusCount=new StatusCount();

  trainingList :Training[] =[];
  certificationList :  Certification[] =[];
  
  mapp: Map<string,number> =new Map();
   map : any;   
 
  anyDemo :any;
  localS : any =localStorage.getItem("userId");

  objectDemo :Object = new Object();

  trainingData1 = new Map<string, number>();


  obj = Object.fromEntries(this.trainingData1);
  json = JSON.stringify(this.obj);


  constructor(private http: HttpClient, private employeeService: EmployeeService, private trainingService : TrainingService) {
    this.trainingData1.set("InProgress", 99);

    console.log("inside constructor" + this.json + " Edited");

  }



  pieChartOptions: ChartOptions<'doughnut'> = {
    responsive: true,
    backgroundColor: "black"
  };
  pieChartLabels = ['InProgress', 'Completed', 'On Hold', 'Not Started'];
  pieChartDatasetsTraining = [{
    label: "Title label",
    data: [12, 20, 4, 6],
    backgroundColor: ["rgb(138, 190, 240)", "rgb(158, 240, 138)", "rgb(240, 138, 138)", "rgb(236, 236, 151)"],
    hoverBackgroundColor: ["rgb(10, 136, 254)", "rgb(51, 255, 0)","rgb(241, 6, 6)", " rgb(255, 255, 0)"],
    hoverBorderColor: ["rgb(10, 136, 254)", "rgb(51, 255, 0)","rgb(241, 6, 6)", " rgb(255, 255, 0)"],
  }];
 
  pieChartDatasetsCertification = [{
    data: [10, 9, 2, 5],
    backgroundColor: ["rgb(138, 190, 240)", "rgb(158, 240, 138)", "rgb(240, 138, 138)", "rgb(236, 236, 151)"],
    hoverBackgroundColor: ["rgb(10, 136, 254)", "rgb(51, 255, 0)","rgb(241, 6, 6)", " rgb(255, 255, 0)"],
    hoverBorderColor: ["rgb(10, 136, 254)", "rgb(51, 255, 0)","rgb(241, 6, 6)", " rgb(255, 255, 0)"],
  }];
  
  pieChartLegend = false;
  public chartColors: any[] = [
    { 
      backgroundColor:["#FF7360", "#6FC8CE", "#red", "#FFFCC4", "#B9E8E0"] 
    }];
  pieChartPlugins = [];

  trainingData =   {
    data: [5, 10, 4, 0]
  };
  certification ={
    data: [1, 3, 0, 0]
  };
  showTab(tab: number){
    this.tab = tab
  }
  loadList(title: string, tableType: string, filterdata: string) {
  }

  ngOnInit() {

   

    this.employeeService.getData(parseInt(this.localS)).subscribe(
      (response) => {
        this.employee = response;
        console.log('Data loaded:', this.employee);
      },
      (error) => {
        console.error('Error loading data:', error);
      }
    );



  



   

    this.employeeService.countTrainingBasedOnStatusForEmp(parseInt(this.localS)).subscribe(

      (response) => {
        this.trainingStatusCount = response;
        console.log('checking trainingData1 has data or not')
        //console.log('Data loaded:', this.trainingData1.get("InProgress"));
        console.log('Get statusCount Data:', this.trainingStatusCount);
        console.log('checking trainingData1 after data is loaded')
      },
      (error) => {
        console.error('Error loading data:', error);
      },
    );


    this.employeeService.countCertificationBasedOnStatusForEmp(parseInt(this.localS)).subscribe(

      (response) => {
        this.certificationStatusCount = response;
        console.log('checking trainingData1 has data or not')
        //console.log('Data loaded:', this.trainingData1.get("InProgress"));
        console.log('Get certificationStatusCount Data:', this.certificationStatusCount);
        console.log('checking trainingData1 after data is loaded')
      },
      (error) => {
        console.error('Error loading data:', error);
      },
    );

    

    

    this.trainingService.getTrainingListForEmp(parseInt(this.localS)).subscribe(

      (response) => {
        this.trainingList=response;
        console.log('checking trainingList has data or not'+this.trainingList);
      }

    );
    

    this.trainingService.getCertificationListForEmp(parseInt(this.localS)).subscribe(

      (response) => {
        this.certificationList=response;
        console.log('checking trainingList has data or not'+this.trainingList);
      }

    );



    

    

  };   


  
  


}
