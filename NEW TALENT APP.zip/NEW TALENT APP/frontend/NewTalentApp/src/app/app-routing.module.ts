import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './auth/login/login.component';
import { AuthRoleGuard } from './service/auth-role.guard';
import { LoginGuard } from './service/login.guard';
import { ForgotPasswordComponent } from './auth/forgot-password/forgot-password.component';

const routes: Routes = [
  { path: '', redirectTo: 'login', pathMatch: 'full' },
  { path: 'login', component: LoginComponent, canActivate: [LoginGuard  ]},
  { path: 'forgotpassword', component: ForgotPasswordComponent}, 
  {
    path: 'dashboard',
    loadChildren: () => import('./home/home.module').then(m => m.HomeModule),
    canActivate: [AuthRoleGuard]
  },
  {
    path: '*', redirectTo: 'login'
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes, 
    // { enableTracing: true }
  )],
  exports: [RouterModule]
})
export class AppRoutingModule { }




