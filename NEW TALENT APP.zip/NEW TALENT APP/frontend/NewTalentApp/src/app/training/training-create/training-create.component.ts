import { Component } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { Title } from "@angular/platform-browser";
import { Router } from "@angular/router";
import { ToastrService } from "ngx-toastr";
import { TrainingService } from "src/app/service/training.service";



@Component({
    selector: 'app-training-create',
    templateUrl: './training-create.component.html',
    styleUrls: ['./training-create.component.css']
})

export class TrainingCreateComponent{

  trainingForm: FormGroup;


  constructor(private trainingService: TrainingService,private toasterService:ToastrService, private fb: FormBuilder, private router: Router,private title:Title) {
    this.trainingForm = this.fb.group({
      id:[],
      training_name: ['',[Validators.required]],
      training_skill_details: ['', Validators.required],
      location: ['',Validators.required],
      trainer_name:['',Validators.required],
      trainer_email: ['', [Validators.required, Validators.email,Validators.pattern('^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$')]],
      trainer_spoc_email: ['',Validators.required],
      training_status: ['',Validators.required],
      start_date: ['',Validators.required],
      end_date: ['',Validators.required],


    })
  }

  validateControl = (controlName: string) => {
    if (this.trainingForm.get(controlName)?.invalid && this.trainingForm.get(controlName)?.touched) {
      return true;
    }
    return false;
  }

  createTraining() {
    var inputData = {

      trainingName: this.trainingForm.controls['training_name'].value,
      trainingSkillDetails: this.trainingForm.controls['training_skill_details'].value,
      location: this.trainingForm.controls['location'].value,
      trainerName: this.trainingForm.controls['trainer_name'].value,
      trainerEmail: this.trainingForm.controls['trainer_email'].value,
      trainerSpocEmail: this.trainingForm.controls['trainer_spoc_email'].value,
      trainingStatus: this.trainingForm.controls['training_status'].value,
      startDate:this.trainingForm.controls['start_date'].value,
      endDate:this.trainingForm.controls['end_date'].value

  }

  console.log(this.trainingForm.controls['training_name'].value);
    this.trainingService.createTraining(inputData).subscribe(result=>{
      // alert('Training  Created Successfully..');
      this.toasterService.success("Training Successfully Created", "Success");
      console.log(result);
      //reset();
      this.router.navigate(['dashboard/training']);
    }, err=>{
      //alert('Property is Added Successfully');
      // alert('You did something wrong.');
      this.toasterService.error("Training Creation failed", "Error");
      console.log(err);
    })
  }

  redirectList() {

    alert('Are you sure cancel the change ?');
    //reset();
    this.router.navigate(['dashboard/training']);

}
}
