import { HttpClient } from "@angular/common/http";
import { Component, OnInit } from "@angular/core";
import { MatDialog } from "@angular/material/dialog";
import { Router } from "@angular/router";
import { NgxSpinnerService } from "ngx-spinner";
import { ToastrService } from "ngx-toastr";
import { Observable } from "rxjs";
import { Training } from "src/app/models/training";
import { AuthService } from "src/app/service/auth.service";
import { TrainingService } from "src/app/service/training.service";
import { TrainingPopupComponent } from "../training-popup/training-popup.component";
// import { TrainingService } from "src/app/Service/training.service";


@Component({
  selector: 'app-training-page',
  templateUrl: './training-page.component.html',
  styleUrls: ['./training-page.component.css']
})

export class TrainingPageComponent implements OnInit {

  filterText: any;
  filteredUsers: Training[] = [];
  selectedFilter = '';
  selectedValue = '';
  filterValue: any[] = []
  trainingList!: Training[];
  page: number = 1;
  totalLength: any;
  newTraining?: Observable<Training[]>;
  isAdmin: boolean = false;
   selectedTrainingId:number=0;
  showPortfolio: boolean=false;


  constructor(private trainingService: TrainingService,private toasterService:ToastrService, private router: Router,
    private httpclient: HttpClient, private authService: AuthService, public dialog: MatDialog, private spinnerService:NgxSpinnerService) {

  }

  ngOnInit(): void {
    this.spinnerService.show();

    this.trainingList=[];
    if (this.authService.isAdmin) {
      this.trainingService.getTrainingList().subscribe((training: any[]) => {
    
        this.trainingList = training;
        // this.trainingList=[];
        // console.log(training);
      }, err => {
        console.log(err);
      });
    } else {
      this.selectedFilter = "status";
      this.filterDropdownValue();
      this.selectedValue="NotStarted";
      this.filter();

    }


    this.isAdmin = this.authService.isAdmin;
    setTimeout(() => {
      /** spinner ends after 5 seconds */
      this.showPortfolio=true;
      this.spinnerService.hide();
    }, 1000);
  }

  addTraining() {
    this.router.navigate(['dashboard/training/createtraining']);
  }


  deleteTraining(id: any) {
    // if (confirm("Are you sure to delete record?"))
    //   this.trainingService.deleteTraining(id).subscribe(res => {
    //     // alert("Record Delete Successfully..")
    //     this.toasterService.error("Training Successfully Deleted ", "Deleted");
    //     this.ngOnInit();
    //   });

      if (confirm("Are you sure to delete record?"))
      this.trainingService.deleteTraining(id).subscribe(res => {
        // alert("Record Delete Successfully..")
        this.toasterService.success("Training Successfully Deleted ", "Deleted");
        this.ngOnInit();
      });


  }

  updateTraining(t: Training) {
    this.router.navigate(['dashboard/training/update', t.trainingId]);
  }

  clickEvent(t: Training){

    this.router.navigate(['dashboard/training/view', t.trainingId]);
  }

  enrollTraining(t: Training) {
    console.log(t.trainingId);
    this.selectedTrainingId=t.trainingId;
    console.log(this.selectedTrainingId,"trninId");
    
    this.loadPopup("Would you like to enroll " + t.trainingName, ["Okay", "Cancel"])
    
  }

  loadPopup(msg: string, button: string[]) {
   const dialogRef= this.dialog.open(TrainingPopupComponent,
      {
        data: {
          message: msg, button: button
        },


      });
      dialogRef.afterClosed().subscribe((result: boolean)=>{
        if(result){
          // http call
          let userID='';
          userID+=localStorage.getItem('userId')?localStorage.getItem('userId'):userID;
          this.trainingService.enrollTraining(+userID,this.selectedTrainingId).subscribe(res=>{
            this.toasterService.success("Successfully Enrolled", "Success");
          }) 
          

        }
        console.log("Result dialog", result);
        
      })
  }reset(){
      window.location.reload();
  }



  filterTraining(field: string, value: string) {
    this.httpclient.get<Training[]>("http://localhost:8010/api/trainings/getAllTrainings?status=Inprogress")
      .subscribe(
        training => {
          this.trainingList = training;
        },
        error => {
          console.error('Error fetching users', error);
        }
      );
  }
  filterDropdownValue() {
    if (this.selectedFilter == 'status') {
      this.filterValue = [
        {
          label: "Inprogress",
          value: "InProgress"
        },
        {
          label: "Complete",
          value: "Complete"
        },
        {
          label: "Not Started",
          value: "NotStarted"
        },
        {
          label: "On Hold",
          value: "OnHold"
        },
      ]
    }
    else {
      this.filterValue = [
        {
          label: "Check",
          value: "check value"
        }
      ]
    }


  }

  filter() {
    // this.filterValue.entries.name
    // console.log(this.selectedValue.split(" "),"out selected value");
    this.trainingService.filterTraining(this.selectedValue).subscribe((training: any[]) => {
      this.trainingList = training;
      console.log(this.selectedValue);
    })




}
}
