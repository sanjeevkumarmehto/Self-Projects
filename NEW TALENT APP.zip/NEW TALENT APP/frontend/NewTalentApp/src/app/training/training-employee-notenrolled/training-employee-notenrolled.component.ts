import { Component } from '@angular/core';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { ToastrService } from 'ngx-toastr';
import { DrilldownListComponent } from 'src/app/home/drilldown-list/drilldown-list.component';
import { Training } from 'src/app/models/training';
import { EmployeeService } from 'src/app/service/employee.service';
import { TrainingService } from 'src/app/service/training.service';
import { TrainingPopupComponent } from '../training-popup/training-popup.component';

@Component({
  selector: 'app-training-employee-notenrolled',
  templateUrl: './training-employee-notenrolled.component.html',
  styleUrls: ['./training-employee-notenrolled.component.css']
})
export class TrainingEmployeeNotenrolledComponent {
  selectedTrainingId: number = 0;
  employeeName?:string;




  constructor(public dialogRef: MatDialogRef<TrainingEmployeeNotenrolledComponent>, public dialog: MatDialog,
    private trainingService: TrainingService, private toasterService: ToastrService,
    private employeeService:EmployeeService) {
      // this.employeeName=employeeService.getEmployeeList().forEach()
  }

  closeDialog() {
    this.dialogRef.close();
  }

  enrollTraining(training: Training = {
    trainingId: 1, trainerName: "", trainerEmail: "", trainerSpocEmail: "",

    trainingSkillDetails: "", trainingStatus: "", trainingName: "Java", startDate: new Date(), endDate: new Date(),
    location: "Noida"
  }) {
    console.log(training.trainingId);
    this.selectedTrainingId = training.trainingId;
    this.loadPopup("Would you like to enroll this training for Test1", ["Okay", "Cancel"])

  }

  loadPopup(msg: string, button: string[]) {
    const dialogRef = this.dialog.open(TrainingPopupComponent,
      {
        data: {
          message: msg, button: button
        },


      });
    dialogRef.afterClosed().subscribe((result: boolean) => {

      if (result) {
        // http call

        let userID = '';
        userID += localStorage.getItem('userId') ? localStorage.getItem('userId') : userID;
        this.trainingService.enrollTraining(+userID, this.selectedTrainingId).subscribe(res => {
          this.toasterService.success("Successfully Enrolled", "Success");
        })


      }
      console.log("Result dialog", result);

    })
  }


}
