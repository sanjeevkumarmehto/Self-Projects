import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TrainingEmployeeNotenrolledComponent } from './training-employee-notenrolled.component';

describe('TrainingEmployeeNotenrolledComponent', () => {
  let component: TrainingEmployeeNotenrolledComponent;
  let fixture: ComponentFixture<TrainingEmployeeNotenrolledComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TrainingEmployeeNotenrolledComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TrainingEmployeeNotenrolledComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
