import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute, Router } from '@angular/router';
import { Employee } from 'src/app/models/employee.model';
import { Training } from 'src/app/models/training';
import { AuthService } from 'src/app/service/auth.service';
import { EmployeeService } from 'src/app/service/employee.service';
import { TrainingService } from 'src/app/service/training.service';
import { TrainingEmployeeNotenrolledComponent } from '../training-employee-notenrolled/training-employee-notenrolled.component';

@Component({
  selector: 'app-training-employee-list',
  templateUrl: './training-employee-list.component.html',
  styleUrls: ['./training-employee-list.component.css']
})
export class TrainingEmployeeListComponent implements OnInit {
  isAdmin: Boolean = true;
  trainingDetails?: Training;
  employeeList!: Employee[];
  page: number = 1;
  totalLength: any;
  constructor(private router:Router,private authService: AuthService, private route: ActivatedRoute,
    private trainingService: TrainingService, private employeSer: EmployeeService,
    private dialog:MatDialog
  ) {

  }
  ngOnInit(): void {
    this.trainingService.getTrainingById(this.route.snapshot.params["id"]).subscribe((training: Training | undefined) => {
      console.log(training);
      this.trainingDetails = training;
    });
    this.employeSer.getEmployeeList().subscribe((employee: Employee[]) => {
      this.employeeList = employee;
      this.employeeList.forEach(t =>t.trainingStatus="InProgress");
      // this.employeeList = [];
    })
 
    this.isAdmin = this.authService.isAdmin;
  }

  showEmployee(){
    this.dialog.open(TrainingEmployeeNotenrolledComponent);
  }
  back() {
    this.router.navigate(['/dashboard/training']);
  }

}
