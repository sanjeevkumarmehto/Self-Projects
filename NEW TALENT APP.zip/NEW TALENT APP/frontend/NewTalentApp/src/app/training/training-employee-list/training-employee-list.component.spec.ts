import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TrainingEmployeeListComponent } from './training-employee-list.component';

describe('TrainingEmployeeListComponent', () => {
  let component: TrainingEmployeeListComponent;
  let fixture: ComponentFixture<TrainingEmployeeListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TrainingEmployeeListComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TrainingEmployeeListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
