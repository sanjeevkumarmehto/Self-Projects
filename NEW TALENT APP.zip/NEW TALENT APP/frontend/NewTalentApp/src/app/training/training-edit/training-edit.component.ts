import { Component, OnInit } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { ActivatedRoute, Router } from "@angular/router";
import { ToastrService } from "ngx-toastr";
import { TrainingService } from "src/app/service/training.service";

@Component({

    selector:'app-training-edit',
    templateUrl:'./training-edit.component.html',
    styleUrls: ['./training-edit.component.css']
})

export class TrainingEditComponent implements OnInit{

  
    trainingId!: any;
    edittrainingForm: FormGroup;
    bufferTrainingForm?: FormGroup;
    constructor(private route: ActivatedRoute,private toasterService:ToastrService, private trainingService: TrainingService,
      private router: Router, private fb: FormBuilder) {
      this.edittrainingForm = this.fb.group({
      trainingId:[''],
      training_name: ['',[Validators.required]],
      training_skill_details: ['', Validators.required],
      location: ['',Validators.required],
      trainer_name:['',Validators.required],
      trainer_email: ['', [Validators.required, Validators.email,Validators.pattern('^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$')]],
      // trainer_email: ['', [Validators.required, Validators.email]],
      trainer_spoc_email: ['', [Validators.required, Validators.email,Validators.pattern('^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$')]],
      // trainer_spoc_email: ['',Validators.required],
      training_status: ['',Validators.required],
      start_date: ['',Validators.required],
      end_date: ['',Validators.required],


      })
    }

    ngOnInit(): void {

      this.trainingService.getTrainingById(this.route.snapshot.params["id"]).subscribe((training => {
        console.log(training);
        var trainingVal = {
          trainingId: training.trainingId,
          training_name: training.trainingName,
          training_skill_details: training.trainingSkillDetails,
          location: training.location,
          trainer_name: training.trainerName,
          trainer_email: training.trainerEmail,
          trainer_spoc_email: training.trainerSpocEmail,
          training_status: training.trainingStatus,
          start_date: training.startDate,
          end_date: training.endDate,
        }

        console.log(trainingVal);
        this.edittrainingForm.patchValue(trainingVal);
        this.edittrainingForm.controls['training_name'].disable();
        // this.edittrainingForm.controls['training_skill_details'].disable();
      })

    )}

    updateTraining() {
      var trainingVal = {
        trainingId: this.edittrainingForm.controls['trainingId'].value,
        trainingName: this.edittrainingForm.controls['training_name'].value,
        trainingSkillDetails: this.edittrainingForm.controls['training_skill_details'].value,
        location: this.edittrainingForm.controls['location'].value,
        trainerName: this.edittrainingForm.controls['trainer_name'].value,
        trainerEmail: this.edittrainingForm.controls['trainer_email'].value,
        trainerSpocEmail: this.edittrainingForm.controls['trainer_spoc_email'].value,
        trainingStatus: this.edittrainingForm.controls['training_status'].value,
        startDate: this.edittrainingForm.controls['start_date'].value,
        endDate: this.edittrainingForm.controls['end_date'].value,
      }
      this.trainingService.updateTraining(trainingVal).subscribe(result=>{
        // alert('Training  Updated Successfully');
        this.toasterService.success("Training Updated Successfully", "Success");
        console.log(result);
        //reset();
        this.router.navigate(['dashboard/training']);
      }, err=>{
        //alert('Property is Added Successfully');
        // alert('You did something wrong.');
        this.toasterService.error("Training Creation failed ", "Error");
        console.log(err);
      })
    }

    redirectList(){
      this.router.navigate(['dashboard/training'])
    }



}
