import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { TrainingCreateComponent } from './training-create/training-create.component';
import { TrainingEditComponent } from './training-edit/training-edit.component';
import { HttpClientModule } from '@angular/common/http';
import { BrowserModule } from '@angular/platform-browser';
import { RouterModule, Routes } from '@angular/router';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import {MatDialogModule} from '@angular/material/dialog';
import { TrainingPageComponent } from './training-page/training-page.component';
import { TrainingPopupComponent } from './training-popup/training-popup.component';
import { NgxPaginationModule } from 'ngx-pagination';
import { TrainingEmployeeListComponent } from './training-employee-list/training-employee-list.component';
import { TrainingEmployeeNotenrolledComponent } from './training-employee-notenrolled/training-employee-notenrolled.component';
import { NgxSpinnerModule } from "ngx-spinner";

const routes: Routes = [
  {path : '', component:TrainingPageComponent, title: 'Training List'},
  {path : 'createtraining', component:TrainingCreateComponent, title: 'Training Create'},
  {path : 'update/:id', component:TrainingEditComponent, title: 'Training Edit'},
  {path: 'view/:id', component: TrainingEmployeeListComponent}
];


@NgModule({
  declarations: [
    TrainingCreateComponent,
    TrainingPageComponent,
    TrainingEditComponent,
    TrainingPopupComponent,
    TrainingEmployeeListComponent,
    TrainingEmployeeNotenrolledComponent
  ], schemas: [
    CUSTOM_ELEMENTS_SCHEMA
  ],
  imports: [
    CommonModule,
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule,
    FormsModule,
    MatButtonModule,
    MatIconModule,
    MatDialogModule,
    NgxSpinnerModule,
    RouterModule.forChild(routes),
    NgxPaginationModule
  ]
})
export class  TrainingModule { }
