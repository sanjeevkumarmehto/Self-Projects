import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CreateCertificationComponent } from './create-certification/create-certification.component';
import { ViewAndUpdateCertificationComponent } from './view-and-update-certification/view-and-update-certification.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule, Routes } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { UpdateCertificationComponent } from './update-certification/update-certification.component';
import { ViewCertificationComponent } from './view-certification/view-certification.component';
import { NgxPaginationModule } from 'ngx-pagination';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { SharedModule } from '../service/shared/shared.module';
import { CertificationPopupComponent } from './certification-popup/certification-popup.component';
import { MatDialogModule } from '@angular/material/dialog';
import { CertificationEmployeeListComponent } from './certification-employee-list/certification-employee-list.component';
// import { SearchPipe } from '../service/search.pipe';
import { NgxSpinnerModule } from "ngx-spinner";



const routes: Routes = [
  { path: '', component: ViewCertificationComponent },
  { path: 'createcertification', component: CreateCertificationComponent },
  { path: 'update/:id', component: UpdateCertificationComponent },
  {path: 'view/:id', component: CertificationEmployeeListComponent}

];

@NgModule({
  declarations: [
    CreateCertificationComponent,
    UpdateCertificationComponent,
    ViewCertificationComponent,
    CertificationPopupComponent,
    CertificationEmployeeListComponent,
    // SearchPipe
  ], schemas: [
    CUSTOM_ELEMENTS_SCHEMA
  ],
  imports: [
    CommonModule,
    FormsModule,
    SharedModule,
    ReactiveFormsModule,
    RouterModule,
    HttpClientModule,
    MatDialogModule,
    RouterModule.forChild(routes),
    NgxPaginationModule,
    MatButtonModule,
    NgxSpinnerModule,
    MatIconModule,
  ],
})
export class CertificationModule { }
