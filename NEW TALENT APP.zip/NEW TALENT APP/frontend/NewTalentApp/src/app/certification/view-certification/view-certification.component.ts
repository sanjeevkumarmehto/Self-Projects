import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CertificationService } from 'src/app/service/certification.service';

import { combineLatest, map, Observable } from 'rxjs';
import { Certification } from 'src/app/models/certification';
import { CreateCertificationComponent } from '../create-certification/create-certification.component';
import { MatDialog } from '@angular/material/dialog';
import { CertificationPopupComponent } from '../certification-popup/certification-popup.component';
import { AuthService } from 'src/app/service/auth.service';
import { ToastrService } from 'ngx-toastr';
import { NgxSpinner, NgxSpinnerService } from 'ngx-spinner';



@Component({
  selector: 'app-view-certification',
  templateUrl: './view-certification.component.html',
  styleUrls: ['./view-certification.component.css']
})
export class ViewCertificationComponent implements OnInit {

  filterText: any;
  page: number = 1;
  totalLength: any;
  filteredUsers: Certification[] = [];
  selectedFilter = '';
  selectedValue = '';
  filterValue: any[] = []
  certificationList!: Certification[];
  newCertification?: Observable<Certification[]>;
  isAdmin: boolean = false;
  selectedCertificationId: number = 0;
  showPortfolio: boolean=false;

  // filteredCertifications!: Observable<Certification[]>;

  constructor(private certificationService: CertificationService, private toasterService: ToastrService, private router: Router,
    private httpclient: HttpClient, public dialog: MatDialog,
    private authService: AuthService, private spinnerService:NgxSpinnerService
  ) {

  }

  ngOnInit(): void {
    this.spinnerService.show();
    this.certificationList = [];
    if (this.authService.isAdmin) {
      this.certificationService.getCertificateList().subscribe(certification => {
       
        this.certificationList = certification;
        
      }, err => {
        console.log(err);
      });
    } else {
      this.selectedFilter = "status";
      this.filterDropdownValue();
      this.selectedValue = "NotStarted";
      this.filter();
    }
    this.isAdmin = this.authService.isAdmin;
    setTimeout(() => {
      /** spinner ends after 5 seconds */
      this.showPortfolio=true;
      this.spinnerService.hide();
    }, 1000);
  }


  addCertification() {

    this.router.navigate(['dashboard/certification/createcertification']);
  }

  deleteCertification(id: any) {
    if (confirm("Are you sure to delete record?"))
      this.certificationService.deleteCertificate(id).subscribe(res => {
        // alert("Record Delete Successfully..")
        this.toasterService.success("Certification Successfully Deleted ", "Delete");
        this.ngOnInit();
      });
  }

  updateCertification(e: Certification) {

    this.router.navigate(['dashboard/certification/update', e.certificationId]);
  }

  enrollTraining(certification: Certification) {
    console.log(certification.certificationId);
    this.selectedCertificationId = certification.certificationId;
    this.loadPopup("Would you like to enroll " + certification.certificationName, ["Okay", "Cancel"])

  }
  loadPopup(msg: string, button: string[]) {
    const dialogRef = this.dialog.open(CertificationPopupComponent,
      {
        data: {
          message: msg, button: button
        },

      });
    dialogRef.afterClosed().subscribe((result: boolean) => {
      if (result) {
        // http call
        let userID = '';
        userID += localStorage.getItem('userId') ? localStorage.getItem('userId') : userID;
        this.certificationService.enrollCertification(+userID, this.selectedCertificationId).subscribe(res => {
          this.toasterService.success("Successfully Enrolled", "Success");
        })


      }
      console.log("Result dialog", result);

    })

  }

  reset() {
    window.location.reload();

  }

  filterTraining(field: string, value: string) {
    this.httpclient.get<Certification[]>("http://localhost:8010/api/certification/getCertification/?status=Inprogress")
      .subscribe(
        training => {
          this.certificationList = training;
        },
        error => {
          console.error('Error fetching users', error);
        }
      );
  }
  filterDropdownValue() {
    if (this.selectedFilter == 'status') {
      this.filterValue = [
        {
          label: "Inprogress",
          value: "InProgress"
        },
        {
          label: "Complete",
          value: "Complete"
        },
        {
          label: "Not Started",
          value: "NotStarted"
        },
        {
          label: "On Hold",
          value: "OnHold"
        },
      ]
    }
    else {
      this.filterValue = [
        {
          label: "Check",
          value: "check value"
        }
      ]
    }


  }

  filter() {
    // this.filterValue.entries.name
    // console.log(this.selectedValue.split(" "),"out selected value");
    this.certificationService.filterTraining(this.selectedValue).subscribe((certification: any[]) => {
      this.certificationList = certification;
      console.log(this.selectedValue);

    })




  }


  clickEvent(t: Certification) {

    this.router.navigate(['dashboard/certification/view', t.certificationId]);
  }
}


