import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { Router } from '@angular/router';
import { CertificationService } from 'src/app/service/certification.service';
import { Certification } from 'src/app/models/certification';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
// src/app/service/certification.service
@Component({
  selector: 'app-create-certification',
  templateUrl: './create-certification.component.html',
  styleUrls: ['./create-certification.component.css']
})


export class CreateCertificationComponent {

  certificationform!:FormGroup;

  // certification = {
  //   certificationId: '',
  //   certificationName: '',
  //   certificationSkill: ''
  // };

  constructor(private certificationService:CertificationService, private toasterService:ToastrService,
    private router: Router,private fb: FormBuilder) {
  this.certificationform = this.fb.group({
  id:[],
 // certificationId: ['',[Validators.required]],
  certificationName: ['', Validators.required],
  // certificationStatus:['',Validators.required],
   certificationSkill: ['',Validators.required],
})
}
validateControl = (controlName: string) => {
  if (this.certificationform.get(controlName)?.invalid && this.certificationform.get(controlName)?.touched) {
    return true;
  }
  return false;
}


createCertificate() {
  this.certificationService.createCertificate(this.certificationform.value).subscribe(result=>{
    // alert('Certificate  Created Successfully..');
    this.toasterService.success("Certification Created Successfully", "Success");
    console.log(result);
    //reset();
    this.router.navigate(['dashboard/certification']);
  }, err=>{
    //alert('Property is Added Successfully');
    // alert('You did something wrong.');
    this.toasterService.error("Certification creation failed", "Error");
    console.log(err);
  })
}

redirectList() {

  alert('Are you sure cancel the change ?');
  //reset();
  this.router.navigate(['dashboard/certification']);

}

  }


