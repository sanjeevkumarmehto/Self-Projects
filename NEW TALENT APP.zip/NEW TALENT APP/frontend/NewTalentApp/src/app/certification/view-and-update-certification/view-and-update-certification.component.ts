import { Component } from '@angular/core';
import { AuthService } from 'src/app/service/auth.service';
import { MockCertificationService } from 'src/app/service/mock-certification.service';


@Component({
  selector: 'app-view-and-update-certification',
  templateUrl: './view-and-update-certification.component.html',
  styleUrls: ['./view-and-update-certification.component.css']
})
export class ViewAndUpdateCertificationComponent {

}
