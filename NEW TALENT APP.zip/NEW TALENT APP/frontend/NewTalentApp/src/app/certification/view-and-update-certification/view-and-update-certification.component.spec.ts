import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewAndUpdateCertificationComponent } from './view-and-update-certification.component';

describe('ViewAndUpdateCertificationComponent', () => {
  let component: ViewAndUpdateCertificationComponent;
  let fixture: ComponentFixture<ViewAndUpdateCertificationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ViewAndUpdateCertificationComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ViewAndUpdateCertificationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
