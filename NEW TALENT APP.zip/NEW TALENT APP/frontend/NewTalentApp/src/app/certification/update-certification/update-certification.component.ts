import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, NgForm, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { CertificationService } from 'src/app/service/certification.service';


@Component({
  selector: 'app-update-certification',
  templateUrl: './update-certification.component.html',
  styleUrls: ['./update-certification.component.css']
})
export class UpdateCertificationComponent implements OnInit {

    certificationId!: any;
  editCertificationForm: FormGroup;
  bufferCertificationForm?: FormGroup;
  
  constructor(private route: ActivatedRoute,private toasterService:ToastrService, private certificationService: CertificationService,
    private router: Router, private fb: FormBuilder) {
    this.editCertificationForm = this.fb.group({
      id: [],
      certificationId: ['', [Validators.required]],
      certificationName: ['', Validators.required],
      certificationStatus:['',Validators.required],
      certificationSkill: ['', Validators.required],



    });
    //this.editCertificationForm.controls['certificationName'].disable();
   // this.editCertificationForm.controls['certificationSkill'].disable();

  }

  ngOnInit(): void {

    this.certificationService.getCertificateById(this.route.snapshot.params["id"]).subscribe(certification => {
      console.log(certification);
      this.editCertificationForm.patchValue(certification);
    })

  }

  updateCertification() {
    let certificationVal = {
        certificationId:this.editCertificationForm.controls['certificationId'].value,
        certificationName:this.editCertificationForm.controls['certificationName'].value,
        certificationStatus:this.editCertificationForm.controls['certificationStatus'].value,
        certificationSkill:this.editCertificationForm.controls['certificationSkill'].value,

    }
    this.certificationService.updateCertificate(certificationVal).subscribe(result=>{
      // alert('Certification  Updated Successfully');
      this.toasterService.success("Certification Successfully Updated ", "Success");
      console.log(result);
      //reset();
      this.router.navigate(['dashboard/certification']);
    }, err=>{
      //alert('Property is Added Successfully');
      // alert('You did something wrong.');
      this.toasterService.error("Certification  Updation failed ", "Error");
      console.log(err);
    })
  }





}
