import { Component, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { DrilldownListComponent } from 'src/app/home/drilldown-list/drilldown-list.component';

@Component({
  selector: 'app-certification-popup',
  templateUrl: './certification-popup.component.html',
  styleUrls: ['./certification-popup.component.css']
})
export class CertificationPopupComponent {
  message: string = "";
  button: string[] = [];
  constructor(public dialogRef: MatDialogRef<DrilldownListComponent>,
  @Inject(MAT_DIALOG_DATA) data: { message: string, button: string[] }) {

  this.message = data.message;
  this.button = data.button;
  console.log(this.message, this.button + " Data from parent")

}
OnClick(){
  // this.toasterService.success("Successfully Enrolled", "Success");
  this.dialogRef.close();
}
 
  onNoClick(): void {
    this.dialogRef.close();
  }
}
