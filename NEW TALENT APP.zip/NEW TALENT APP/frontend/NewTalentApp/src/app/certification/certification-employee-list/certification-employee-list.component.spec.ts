import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CertificationEmployeeListComponent } from './certification-employee-list.component';

describe('CertificationEmployeeListComponent', () => {
  let component: CertificationEmployeeListComponent;
  let fixture: ComponentFixture<CertificationEmployeeListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CertificationEmployeeListComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CertificationEmployeeListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
