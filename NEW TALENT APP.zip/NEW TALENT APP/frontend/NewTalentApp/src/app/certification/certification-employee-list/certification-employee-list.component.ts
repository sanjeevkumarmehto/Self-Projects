import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Certification } from 'src/app/models/certification';
import { Employee } from 'src/app/models/employee.model';
import { AuthService } from 'src/app/service/auth.service';
import { CertificationService } from 'src/app/service/certification.service';
import { EmployeeService } from 'src/app/service/employee.service';

@Component({
  selector: 'app-certification-employee-list',
  templateUrl: './certification-employee-list.component.html',
  styleUrls: ['./certification-employee-list.component.css']
})
export class CertificationEmployeeListComponent implements OnInit {


  isAdmin: boolean = true;
  certificationDetails?: Certification;
  certificationList!: Certification[];
  employeeList!: Employee[];
  page: number = 1;
  totalLength: any;
  constructor(private authService: AuthService, private route: ActivatedRoute,
    private certificationService: CertificationService, private employeSer: EmployeeService,
    private router: Router
  ) {

  }
  ngOnInit(): void {
    this.certificationService.getCertificateById(this.route.snapshot.params["id"]).subscribe((certification: Certification | undefined) => {
      console.log(certification);
      this.certificationDetails = certification;
    });
    this.employeSer.getEmployeeList().subscribe((employee: Employee[]) => {
      this.employeeList = employee;
      this.employeeList.forEach(t =>t.certificationStatus="InProgress");
      // this.employeeList = [];
    })

    this.isAdmin = this.authService.isAdmin;
  }

  back() {
    this.router.navigate(['/dashboard/certification']);
  }
  

}
