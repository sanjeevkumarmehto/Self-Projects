import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Employee } from '../models/employee.model';
import { Observable, tap } from 'rxjs';
import { environment } from 'src/environments/environment';


import { StatusCount } from '../models/statusCount';
@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

  private apiUrl: string = environment.employeeServiceAPI + 'api/employee';

  private trainingAPI : string = environment.trainingServiceAPI +'api/trainings';


  private certificationAPI : string = environment.trainingServiceAPI +'api/certification';
  

  constructor(private http: HttpClient) {
}


  createEmployee(employee: Employee): Observable<Employee> {
    return this.http.post<Employee>(this.apiUrl+"/createemp", employee);
  }
  getEmployeeList(): Observable<Employee[]> {
    return this.http.get<Employee[]>(this.apiUrl+"/"+"getall");
  }
  getEmployeeById(empId: number): Observable<Employee> {
    const url = `${this.apiUrl}/getEmployeeById/${empId}`;
    return this.http.get<Employee>(url);
  }

  // updateEmployee(employee: Employee): Observable<Employee> {
  //   const url = `${this.apiUrl}/${employee.id}`;
  //       return this.http.put<Employee>(url, employee).pipe(tap(() => this.getEmployeeList()));
  // }

  updateEmployee(employee: any): Observable<Employee> {
    const url = `${this.apiUrl}/UpdateEmp/${employee.empId}`;
        return this.http.put<any>(url, employee).pipe(tap(() => this.getEmployeeList()));
  }


  deleteEmployee(id: number): Observable<any> {
    // we can store the URL path here,
    return this.http.delete(this.apiUrl + "/DeleteEmpbyID/" + id);
  }


 // count

 /**  
 countTrainingBasedOnStatus(id: number) : Observable<any>
 {  
    const url = `${this.apiUrl}/GetEmpbyID/${empId}`;
    return this.http.get

 }
  */


 

  getData(empId: number): Observable<Employee> {
    const url = `${this.apiUrl}/getEmployeeById/${empId}`;
    return this.http.get<Employee>(url);
  }

  /**  
  countTrainingBasedOnStatusForEmp1(empId: number) : Observable<EmployeeTrainingMapping[]>{
    const url = `${this.trainingAPI}/countTrainingBasedOnStatusForEmp/${empId}`;
    return this.http.get<EmployeeTrainingMapping[]>(url);
  }
  */

  /*
  countTrainingBasedOnStatusForEmp(empId: number) : Observable<Map<string, number>>{
    const url = `${this.trainingAPI}/countTrainingBasedOnStatusForEmp1/${empId}`;
    return this.http.get<Map<string, number>>(url);
  } */
     /** 
  countCertificationBasedOnStatusForEmp(empId: number) : Observable<EmployeeCertificationMapping[]>{
    const url = `${this.trainingAPI}/countTrainingBasedOnStatusForEmp/${empId}`;
    return this.http.get<EmployeeCertificationMapping[]>(url);
  }
    */
  /**   
    countTrainingBasedOnStatusForEmp3(empId: number) : Observable<EmployeeTrainingMappingDTO[]>{
      const url = `${this.trainingAPI}/countTrainingBasedOnStatusForEmp3/${empId}`;
      return this.http.get<EmployeeTrainingMappingDTO[]>(url);
    }

  */
  countTrainingBasedOnStatusForEmp4(empId: number) : Observable<Map<string,number>>{
    const url = `${this.trainingAPI}/countTrainingBasedOnStatusForEmp4/${empId}`;
    return this.http.get<Map<string,number>>(url);
  }


  countTrainingBasedOnStatusForEmp9(empId: number) : Observable<StatusCount>{
    const url = `${this.trainingAPI}/countTrainingBasedOnStatusForEmp9/${empId}`;
    return this.http.get<StatusCount>(url);
  }

  countTrainingBasedOnStatusForEmp(empId: number) : Observable<StatusCount>{
    const url = `${this.trainingAPI}/countTrainingBasedOnStatusForEmp/${empId}`;
    return this.http.get<StatusCount>(url);
  }

  countCertificationBasedOnStatusForEmp(empId: number) : Observable<StatusCount>{
    const url = `${this.certificationAPI}/countCertificationBasedOnStatusForEmp/${empId}`;
    return this.http.get<StatusCount>(url);
  }

}
