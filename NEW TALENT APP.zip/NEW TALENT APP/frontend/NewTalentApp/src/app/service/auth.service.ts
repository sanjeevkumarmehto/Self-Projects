import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Router } from "@angular/router";

import { Observable } from "rxjs";
import { environment } from "src/environments/environment";

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  apiUrl: string = environment.employeeServiceAPI;
  private _isAdmin: boolean = false;
  private _loggedIn: boolean = false;
  userId: any;
  userDetails: any;

  constructor(private http: HttpClient, private router: Router) {
    this.userId = localStorage.getItem('userId');
    this.isAdmin = localStorage.getItem('isAdmin') == 'true' ? true : false;
    if (this.userId > 0) {
      this.loggedIn = true;
    }
  }
  
  public get loggedIn(): boolean {
    return this._loggedIn;
  }
  public set loggedIn(value: boolean) {
    this._loggedIn = value;
  }
  public get isAdmin(): boolean {
    return this._isAdmin;
  }
  public set isAdmin(value: boolean) {
    this._isAdmin = value;
  }


  loginEmployee(employee: any): Observable<any> {
    return this.http.post<any>(this.apiUrl + "api/employee/login", employee);
  }

  logout() {
    localStorage.clear(); 
    this.isAdmin = false;
    this.loggedIn = false;
    this.router.navigate(["/login"]);
  }
//http://localhost:8000/api/employee/forgotPassword
  forgotPassword(employee: any): Observable<any>{
    console.log('inside auth service and forgot password' +employee);
    return this.http.put<any>(this.apiUrl + "api/employee/forgotPassword", employee.email );

  }
}
