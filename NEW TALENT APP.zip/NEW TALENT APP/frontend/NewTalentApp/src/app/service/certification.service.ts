import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Certification } from '../models/certification';
import { Observable, tap } from 'rxjs';
import { isQualifiedName } from 'typescript';
import { environment } from 'src/environments/environment';
import { StatusCount } from '../models/statusCount';

@Injectable({
  providedIn: 'root'
})
export class CertificationService {


  private apiUrl: string = 'http://localhost:8010/api/certification';
  // apiUrl =`${environment.apiBaseUrl}/users`;

  // private employeeSubject = new BehaviorSubject<Employee[]>([]);

  // public employees: Observable<Employee[]> = this.employeeSubject.asObservable();


  //private apiUrl: string = environment.employeeServiceAPI + 'api/employee';

  // private apiUrl: string = environment.trainingServiceAPI + 'api/trainings';


  // private trainingAPI: string = environment.trainingServiceAPI + 'api/trainings';


  // private certificationAPI: string = environment.trainingServiceAPI + 'api/certification';




  constructor(private http: HttpClient) {
    this.getCertificateList();
}

createCertificate(certification: Certification): Observable<Certification> {
    return this.http.post<Certification>(this.apiUrl+"/createCertification", certification);
  }
getCertificateList(): Observable<Certification[]> {
    return this.http.get<Certification[]>(this.apiUrl+"/"+"getAllCertifications");
  }

getCertificateById(CertificationId: number): Observable<Certification> {
    const url = `${this.apiUrl}/getCertification/${CertificationId}`;
    return this.http.get<Certification>(url);
  }

updateCertificate(certificate: any): Observable<Certification> {
    const url = `${this.apiUrl}/updateCertification/${certificate.certificationId}`;
        return this.http.put<any>(url, certificate).pipe(tap(() => this.getCertificateList()));
  }

deleteCertificate(id: number): Observable<any> {
    // we can store the URL path here,
    return this.http.delete(this.apiUrl + "/deleteCertification/" + id);
  }

  filterTraining(value: String):Observable<any> {
    if(value){
      return this.http.get(this.apiUrl + "/getCertification/status?value=" + value);
    }
    else{
      return this.http.get(this.apiUrl + "/getCertification/status");
    }
  }

  countCertificationOnStatus(empId: number) : Observable<StatusCount>{
    const url = `${this.apiUrl}/countCertificationOnStatus`;
    return this.http.get<StatusCount>(url);
  }

  enrollCertification(employeeId:number,certificationId:number): Observable<any>{
    const url = `${this.apiUrl}/enroll`;
    const requestBody = {
      employeeID: employeeId,
      certificationID: certificationId
    }
    return this.http.post<any>(url, requestBody);
  }


}
