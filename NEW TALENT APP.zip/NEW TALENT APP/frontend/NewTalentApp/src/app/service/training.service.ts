import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Observable } from "rxjs";
import { Training } from "../models/training";
import { environment } from "src/environments/environment";
import { Certification } from "../models/certification";
import { StatusCount } from "../models/statusCount";

@Injectable({
  providedIn: 'root'
})
export class TrainingService {

  private apiUrl: string = environment.trainingServiceAPI + 'api/trainings';


  private trainingAPI: string = environment.trainingServiceAPI + 'api/trainings';


  private certificationAPI: string = environment.trainingServiceAPI + 'api/certification';



  constructor(private httpClient: HttpClient) {
    //this.getTrainingList();
  }


  createTraining(training: any): Observable<any[]> {
    return this.httpClient.post<any>(this.apiUrl + "/" + "createTraining", training);
  }

  getTrainingById(trainingId: number): Observable<Training> {
    const url = `${this.apiUrl}/getTraining/${trainingId}`;
    return this.httpClient.get<Training>(url);
  }

  getTrainingList(): Observable<Training[]> {
    return this.httpClient.get<Training[]>(this.apiUrl + "/" + "getAllTrainings");
  }



  updateTraining(training: Training): Observable<Training> {
    const url = `${this.apiUrl}/updateTraining/${training.trainingId}`;
    return this.httpClient.put<Training>(url, training);
  }

  deleteTraining(id: number): Observable<any> {
    // we can store the URL path here,
    return this.httpClient.delete(this.apiUrl + "/deleteTraining/" + id);
  }
  // http://localhost:8010/api/trainings/getTraining/status
  filterTraining(value: String): Observable<any> {
    if (value) {
      return this.httpClient.get(this.apiUrl + "/getTraining/status?value=" + value);
    }
    else {
      return this.httpClient.get(this.apiUrl + "/getTraining/status");
    }
  }

  getTrainingListForEmp(empId: number): Observable<Training[]> {
    return this.httpClient.get<Training[]>(this.trainingAPI + "/" + "getAllTrainingsForEmp/" + empId);
  }

  getCertificationListForEmp(empId: number): Observable<Certification[]> {
    return this.httpClient.get<Certification[]>(this.certificationAPI + "/" + "getAllCertificationForEmp/" + empId);
  }


  countTrainingOnStatus(empId: number): Observable<StatusCount> {
    const url = `${this.trainingAPI}/countTrainingOnStatus`;
    return this.httpClient.get<StatusCount>(url);
  }

  enrollTraining(employeeId: number, trainingId?: number): Observable<any> {
    const url = `${this.trainingAPI}/enroll`;
    const requestBody = {
      employeeID: employeeId,
      trainingID: trainingId
    }
    return this.httpClient.post<any>(url, requestBody);
  }

}