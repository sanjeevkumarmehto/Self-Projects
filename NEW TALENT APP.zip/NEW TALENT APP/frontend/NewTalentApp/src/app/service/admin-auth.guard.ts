import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Observable } from 'rxjs';
import { AuthService } from './auth.service';

@Injectable({
  providedIn: 'root'
})
export class AdminAuthGuard implements CanActivate {
  constructor(private authService: AuthService, private router: Router){

  }
  canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot) {
    if(this.authService.isAdmin){
      console.log(this.authService.isAdmin)
      return true;
    }
    else if(this.authService.loggedIn) {
      this.router.navigate(['/dashboard/profile']);
      return false;
    } else {
      this.router.navigate(['/login']);
      return false;
    }
  }
  
}
