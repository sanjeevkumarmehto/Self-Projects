import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class MockCertificationService {
  private apiUrl = 'http://localhost:3000/certifications';

  constructor(private http: HttpClient) { }
  
  addCertification(certification: any): Observable<any> {
    return this.http.post<any>(this.apiUrl, certification);
  }

  getCertifications(): Observable<any> {
    return this.http.get<any>(this.apiUrl);
}
}
