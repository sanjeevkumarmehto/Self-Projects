import { Component } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Title } from '@angular/platform-browser';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { AuthService } from 'src/app/service/auth.service';
import { EmployeeService } from 'src/app/service/employee.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {

  employeeForm: FormGroup;


  constructor(private authService: AuthService, private toasterService: ToastrService,
    private fb: FormBuilder, private router: Router) {
    this.employeeForm = this.fb.group({

      
      password: ['', Validators.required],
      employeeEmailId:['', [Validators.required, Validators.email]],
      


    })
  }

  validateControl = (controlName: string) => {
    if (this.employeeForm.get(controlName)?.invalid && this.employeeForm.get(controlName)?.touched) {
      return true;
    }
    return false;
  }

  LoginEmployee() {
    localStorage.clear();
    let employee = {
      email: this.employeeForm.controls['employeeEmailId'].value,
      password: this.employeeForm.controls['password'].value
    }
    this.authService.loginEmployee(employee).subscribe(result=>{
      if(result.loggedIn ){
        localStorage.setItem('userId', result.userId);
        this.authService.isAdmin = result.admin;
        this.authService.loggedIn = result.loggedIn;
        localStorage.setItem('isAdmin', result.admin);
        this.router.navigate(['/dashboard']);
      } else if(result.loggedIn && !result.admin){
        this.router.navigate(['/dashboard/profile']);
      }
    }, err=>{
      this.toasterService.error("Server Error while login", "Error")
      console.log(err);
    })
  }
}
