import { Component } from '@angular/core';
import { AbstractControl, FormBuilder, FormGroup, NgForm, ValidationErrors, ValidatorFn, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/service/auth.service';

@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.css']
})
export class ForgotPasswordComponent {

  employeeForm: FormGroup;
  msg?: string;


  constructor(private authService: AuthService,
    private fb: FormBuilder, private router: Router) {
    this.employeeForm = this.fb.group({
      // email: ['', [Validators.required, Validators.email,Validators.pattern('^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$')]],
      employeeEmailId:['', [Validators.required, Validators.email,Validators.pattern('^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$')]],
      password: ['', [Validators.required, Validators.min(8), Validators.pattern(/^(?=.*[A-Z])(?=.*[!@#$%^&*(),.?":{}|<>])(?=.*\d).{8,}$/)]],
      confirmpassword: ['', [Validators.required, Validators.min]],
      
    },
    {
      // validators: this.passwordMatchValidators,
    }
  
  )
  }



  passwordMatchValidators(control :AbstractControl){
    return  control.get('password')?.value=== control.get('confirmpassword') ? null : {mismatch : true}

  }

  validateControl = (controlName: string) => {
    if (this.employeeForm.get(controlName)?.invalid && this.employeeForm.get(controlName)?.touched) {
      return true;
    }
    return false;
  }
  
  forgotPassword() {
   
    let employee = {
      employeeEmailId: this.employeeForm.controls['employeeEmailId'].value,
      password: this.employeeForm.controls['password'].value
    }

    console.log('this is forgot password');
    
    this.authService.forgotPassword(employee).subscribe((result : any)=>{
      // this.msg=result;
      alert(result.msg);
      console.log("inside employee",employee);
      this.router.navigate(['/login']);

    },err=>{
      //alert('Property is Added Successfully');
      alert('Invalid userid'); 
      console.log(err);
    })

  }

}

export function confirmPasswordValidator(controlName: string, matchingControlName: string): ValidatorFn {
  return (control: AbstractControl): ValidationErrors | null => {
    const formGroup = control as AbstractControl;
    const password = formGroup.get(controlName)?.value;
    const confirmPassword = formGroup.get(matchingControlName)?.value;

    if (password !== confirmPassword) {
      formGroup.get(matchingControlName)?.setErrors({ confirmPassword: true });
      return { confirmPassword: true };
    } else {
      formGroup.get(matchingControlName)?.setErrors(null);
      return null;
    }
  };
}
