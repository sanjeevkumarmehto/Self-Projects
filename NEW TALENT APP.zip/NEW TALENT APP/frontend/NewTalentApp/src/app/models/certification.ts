export class Certification {
  certificationId!:number;
  certificationName!:string;
  certificationStatus!:string;
  certificationSkill!:string;


}
