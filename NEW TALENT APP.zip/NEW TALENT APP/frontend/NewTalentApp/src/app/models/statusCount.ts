

export class StatusCount {
    inProgress?: number;
	completed?: number;
	notStarted ?: number;
	onHold ?: number;
}
