
export  class Login{
    email ?: string ="";
    name ?: string ="";
    password ?: string ="";
    isAdmin ?: boolean =false;
    
}