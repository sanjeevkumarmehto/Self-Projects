export class Employee {
    // employeeId?: number=0;
    // employeeEmailId: string="";
    // fullName: string="";
    // location: string="";
    // primarySkills: string="";
    // trainingStatus: string="";
    // certificationName: string="";
    // certificationStatus: string="";
    // grade:string="";
    // id: any;
    empId!: number;
    practiseName?: string = "";
    sub_practice_name?: string = "";
    fullName?: string = "";
    email?: string = "";
    location: string = "";
    grade?: string = "";
    primarySkills?: string = "";
    id?: any;
    certificationStatus?:string='';
    trainingStatus?:string='';
}

// employeeName: ['', Validators.required],
// employeeEmailId: ['', [Validators.required, Validators.email]],
// type: ['', Validators.required],