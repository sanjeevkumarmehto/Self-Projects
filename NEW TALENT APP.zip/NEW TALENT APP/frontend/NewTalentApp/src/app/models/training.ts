export class Training {
  trainingId!: number;
  trainingName!: string;
  trainingSkillDetails!: string;
  location!: string;
  trainerName!: string;
  trainerEmail!: string;
  trainerSpocEmail!: string;
  trainingStatus!: string;
  startDate!: Date;
  endDate!: Date;
}
