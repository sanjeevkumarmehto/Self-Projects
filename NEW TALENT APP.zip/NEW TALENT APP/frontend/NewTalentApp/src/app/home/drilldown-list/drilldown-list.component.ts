import { Component, Inject, Input } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { Router } from '@angular/router';

@Component({
  selector: 'app-drilldown-list',
  templateUrl: './drilldown-list.component.html',
  styleUrls: ['./drilldown-list.component.css']
})
export class DrilldownListComponent {
  title: string = ''; 
  tableType: string = ''//training, employee, certification
  filterdata: string = ''; //Inprogress, Completed, onHold, notStarted
  statusTitle: string = '';
  data: any[] = [];

  constructor(public dialogRef: MatDialogRef<DrilldownListComponent>,
    @Inject(MAT_DIALOG_DATA) data: { dialogTitle: string, tableType: string, status: string },
  private router: Router) {
    this.title = data.dialogTitle;
    this.tableType = data.tableType;
    this.filterdata = data.status;
    if(this.filterdata == 'Inprogress') {
      this.statusTitle = 'inprogress';
    } else if(this.filterdata == 'Completed') {
      this.statusTitle = 'completed';
    } else if(this.filterdata == 'onHold') {
      this.statusTitle = 'onhold';
    } else if(this.filterdata == 'notStarted') {
      this.statusTitle = 'not started';
    }
  }
  goToTrainingList(){
    this.dialogRef.close();
    this.router.navigate(['dashboard/training/createtraining'])
  }
  closeDialog(){
    this.dialogRef.close();

  }
}
