import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DrilldownListComponent } from './drilldown-list.component';

describe('DrilldownListComponent', () => {
  let component: DrilldownListComponent;
  let fixture: ComponentFixture<DrilldownListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DrilldownListComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DrilldownListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
