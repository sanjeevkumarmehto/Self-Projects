import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/service/auth.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit{
  listofNavigation: string[] = [];
  isAdmin: boolean = true;

  constructor(private authService: AuthService){
    
  }
  ngOnInit()  {
    this.listofNavigation = [
      'dashboard', 
      'profile', 
      'employeeList', 
      'addEmployee', 
      'enrollEmployee', 
      'trainingList', 
      'addTraining',
      'enrollTraining',
      'certificationList', 
      'addCertification', 
      'enrollCertification'
    ]
    this.isAdmin = this.authService.isAdmin;
  }

  logout(){
    this.authService.logout();
  }
}
