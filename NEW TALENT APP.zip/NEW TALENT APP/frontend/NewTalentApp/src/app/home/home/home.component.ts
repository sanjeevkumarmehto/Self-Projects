import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ChartOptions } from 'chart.js';
import { DrilldownListComponent } from '../drilldown-list/drilldown-list.component';
import { CertificationService } from 'src/app/service/certification.service';
import { StatusCount } from 'src/app/models/statusCount';
import { TrainingService } from 'src/app/service/training.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  localS : any =localStorage.getItem("userId");

  trainingStatusCount : StatusCount=new StatusCount();
  certificationStatusCount : StatusCount=new StatusCount();


  pieChartOptions: ChartOptions<'doughnut'> = {
    responsive: true,
    backgroundColor: "black"
  };
  pieChartLabels = ['InProgress', 'Completed', 'On Hold', 'Not Started'];
  pieChartDatasetsTraining = [{
    label: "Title label",
    data: [12, 20, 4, 6],
    backgroundColor: ["rgb(138, 190, 240)", "rgb(158, 240, 138)", "rgb(240, 138, 138)", "rgb(236, 236, 151)"],
    hoverBackgroundColor: ["rgb(10, 136, 254)", "rgb(51, 255, 0)","rgb(241, 6, 6)", " rgb(255, 255, 0)"],
    hoverBorderColor: ["rgb(10, 136, 254)", "rgb(51, 255, 0)","rgb(241, 6, 6)", " rgb(255, 255, 0)"],
  }];
  pieChartDatasetsEmployeeTraining = [{
    data: [300, 900, 60, 120],
    backgroundColor: ["rgb(138, 190, 240)", "rgb(158, 240, 138)", "rgb(240, 138, 138)", "rgb(236, 236, 151)"],
    hoverBackgroundColor: ["rgb(10, 136, 254)", "rgb(51, 255, 0)","rgb(241, 6, 6)", " rgb(255, 255, 0)"],
    hoverBorderColor: ["rgb(10, 136, 254)", "rgb(51, 255, 0)","rgb(241, 6, 6)", " rgb(255, 255, 0)"],
  }];
  pieChartDatasetsCertification = [{
    data: [10, 9, 2, 5],
    backgroundColor: ["rgb(138, 190, 240)", "rgb(158, 240, 138)", "rgb(240, 138, 138)", "rgb(236, 236, 151)"],
    hoverBackgroundColor: ["rgb(10, 136, 254)", "rgb(51, 255, 0)","rgb(241, 6, 6)", " rgb(255, 255, 0)"],
    hoverBorderColor: ["rgb(10, 136, 254)", "rgb(51, 255, 0)","rgb(241, 6, 6)", " rgb(255, 255, 0)"],
  }];
  pieChartDatasetsEmployeeCertifiction = [{
    data: [200, 100, 40, 20],
    backgroundColor: ["rgb(138, 190, 240)", "rgb(158, 240, 138)", "rgb(240, 138, 138)", "rgb(236, 236, 151)"],
    hoverBackgroundColor: ["rgb(10, 136, 254)", "rgb(51, 255, 0)","rgb(241, 6, 6)", " rgb(255, 255, 0)"],
    hoverBorderColor: ["rgb(10, 136, 254)", "rgb(51, 255, 0)","rgb(241, 6, 6)", " rgb(255, 255, 0)"],
  }];
  pieChartLegend = false;
  public chartColors: any[] = [
    { 
      backgroundColor:["#FF7360", "#6FC8CE", "#red", "#FFFCC4", "#B9E8E0"] 
    }];
  pieChartPlugins = [];

  ngOnInit(): void {
    // this.certificationService.countCertificationOnStatus.subs

    this.trainingService.countTrainingOnStatus(parseInt(this.localS)).subscribe(
      (response) => {
        this.trainingStatusCount = response;
        console.log('Data loaded:', this.trainingStatusCount);
      },
      (error) => {
        console.error('Error loading data:', error);
      }
    );

    this.certificationService.countCertificationOnStatus(parseInt(this.localS)).subscribe(
      (response) => {
        this.certificationStatusCount = response;
        console.log('Data loaded:', this.certificationStatusCount);
      },
      (error) => {
        console.error('Error loading data:', error);
      }
    );
   


    

  }
  constructor(public dialog: MatDialog, private certificationService: CertificationService,private trainingService : TrainingService) {

  }

  loadList(title: string, tableType: string, filterdata: string) {
    this.dialog.open(DrilldownListComponent,
      {
        data: {
          dialogTitle: title, tableType: tableType, status: filterdata
        },
        height:"400px",
        width:"500px"

      });

  }


  // this.countCertificationOnStatus;

  

}
