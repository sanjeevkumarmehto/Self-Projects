import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { RouterModule, Routes } from '@angular/router';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatListModule } from '@angular/material/list';
import { MatDividerModule } from '@angular/material/divider';
import { NgChartsModule } from 'ng2-charts';
import {MatDialogModule} from '@angular/material/dialog';

import { HomeComponent } from './home/home.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { FooterComponent } from './footer/footer.component';
import { DrilldownListComponent } from './drilldown-list/drilldown-list.component';
import { EmployeeAuthGuard } from '../service/employee-auth.guard';
import { AdminAuthGuard } from '../service/admin-auth.guard';


const routes: Routes = [
  // {path:"", redirectTo: 'profile', pathMatch: 'full'},
  {
    path: "", component: DashboardComponent,
    children: [
      {
        path: "",
        component: HomeComponent,
        canActivate:[AdminAuthGuard]
      },
      {
        path: "employee",
        loadChildren: () => import('../employee/employee.module').then(m => m.EmployeeModule),
        canActivate:[AdminAuthGuard]
      },
      {
        path: "training",
        loadChildren: () => import('../training/training.module').then(m => m.TrainingModule)
      },
      {
        path: "certification",
        loadChildren: () => import('../certification/certification.module').then(m => m.CertificationModule)
      },
      {
        path: "profile",
        loadChildren: () => import('../profile/profile.module').then(m => m.ProfileModule),
        canActivate: [EmployeeAuthGuard]
      }
    ]
  }

];

@NgModule({
  declarations: [
    HomeComponent,
    DashboardComponent,
    FooterComponent,
    DrilldownListComponent
  ],
  imports: [
    CommonModule,
    MatToolbarModule,
    MatIconModule,
    MatButtonModule,
    MatSidenavModule,
    MatListModule,
    MatDividerModule,
    NgChartsModule,
    MatDialogModule,
    RouterModule.forChild(routes),
  ]
})
export class HomeModule { }
