export const environment = {
    apiUrl:'http://localhost:8000/',
    employeeServiceAPI:"http://localhost:8000/",
    trainingServiceAPI:"http://localhost:8010/"
}
